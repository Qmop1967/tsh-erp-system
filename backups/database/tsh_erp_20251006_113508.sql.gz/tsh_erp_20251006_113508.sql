--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Homebrew)
-- Dumped by pg_dump version 15.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: accounttypeenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.accounttypeenum AS ENUM (
    'ASSET',
    'LIABILITY',
    'EQUITY',
    'REVENUE',
    'EXPENSE'
);


ALTER TYPE public.accounttypeenum OWNER TO "khaleelal-mulla";

--
-- Name: cashboxtypeenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.cashboxtypeenum AS ENUM (
    'SALESPERSON',
    'BRANCH',
    'MAIN',
    'PETTY_CASH'
);


ALTER TYPE public.cashboxtypeenum OWNER TO "khaleelal-mulla";

--
-- Name: cashpaymentmethodenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.cashpaymentmethodenum AS ENUM (
    'CASH',
    'DIGITAL',
    'BANK_TRANSFER',
    'CHECK'
);


ALTER TYPE public.cashpaymentmethodenum OWNER TO "khaleelal-mulla";

--
-- Name: currencyenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.currencyenum AS ENUM (
    'IQD',
    'USD',
    'RMB'
);


ALTER TYPE public.currencyenum OWNER TO "khaleelal-mulla";

--
-- Name: invoicestatusenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.invoicestatusenum AS ENUM (
    'DRAFT',
    'PENDING',
    'PAID',
    'PARTIALLY_PAID',
    'OVERDUE',
    'CANCELLED',
    'REFUNDED'
);


ALTER TYPE public.invoicestatusenum OWNER TO "khaleelal-mulla";

--
-- Name: invoicetypeenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.invoicetypeenum AS ENUM (
    'SALES',
    'PURCHASE',
    'CREDIT_NOTE',
    'DEBIT_NOTE'
);


ALTER TYPE public.invoicetypeenum OWNER TO "khaleelal-mulla";

--
-- Name: journaltypeenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.journaltypeenum AS ENUM (
    'GENERAL',
    'SALES',
    'PURCHASE',
    'CASH',
    'BANK'
);


ALTER TYPE public.journaltypeenum OWNER TO "khaleelal-mulla";

--
-- Name: migrationstatusenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.migrationstatusenum AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'FAILED',
    'REQUIRES_REVIEW'
);


ALTER TYPE public.migrationstatusenum OWNER TO "khaleelal-mulla";

--
-- Name: paymentmethodenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.paymentmethodenum AS ENUM (
    'CASH',
    'CARD',
    'MOBILE',
    'CREDIT',
    'VOUCHER'
);


ALTER TYPE public.paymentmethodenum OWNER TO "khaleelal-mulla";

--
-- Name: paymenttermsenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.paymenttermsenum AS ENUM (
    'IMMEDIATE',
    'NET_7',
    'NET_15',
    'NET_30',
    'NET_60',
    'NET_90',
    'CUSTOM'
);


ALTER TYPE public.paymenttermsenum OWNER TO "khaleelal-mulla";

--
-- Name: possessionstatusenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.possessionstatusenum AS ENUM (
    'OPEN',
    'CLOSED',
    'SUSPENDED'
);


ALTER TYPE public.possessionstatusenum OWNER TO "khaleelal-mulla";

--
-- Name: postransactiontypeenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.postransactiontypeenum AS ENUM (
    'SALE',
    'REFUND',
    'EXCHANGE',
    'VOID'
);


ALTER TYPE public.postransactiontypeenum OWNER TO "khaleelal-mulla";

--
-- Name: regionenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.regionenum AS ENUM (
    'KARBALA',
    'NAJAF',
    'BABEL',
    'BAGHDAD',
    'BASRA',
    'MOSUL',
    'ERBIL',
    'DUHOK',
    'SULAYMANIYAH',
    'KIRKUK',
    'ANBAR',
    'DIYALA',
    'SALAHUDDIN',
    'WASIT',
    'QADISIYYAH',
    'MUTHANNA',
    'DHI_QAR',
    'MAYSAN'
);


ALTER TYPE public.regionenum OWNER TO "khaleelal-mulla";

--
-- Name: transactionstatusenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.transactionstatusenum AS ENUM (
    'DRAFT',
    'POSTED',
    'CANCELLED'
);


ALTER TYPE public.transactionstatusenum OWNER TO "khaleelal-mulla";

--
-- Name: transferstatusenum; Type: TYPE; Schema: public; Owner: khaleelal-mulla
--

CREATE TYPE public.transferstatusenum AS ENUM (
    'PENDING',
    'APPROVED',
    'RECEIVED',
    'REJECTED',
    'CANCELLED'
);


ALTER TYPE public.transferstatusenum OWNER TO "khaleelal-mulla";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounting_periods; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.accounting_periods (
    id integer NOT NULL,
    fiscal_year_id integer NOT NULL,
    name_ar character varying(100) NOT NULL,
    name_en character varying(100) NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    is_closed boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.accounting_periods OWNER TO "khaleelal-mulla";

--
-- Name: accounting_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.accounting_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounting_periods_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: accounting_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.accounting_periods_id_seq OWNED BY public.accounting_periods.id;


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    chart_account_id integer NOT NULL,
    currency_id integer NOT NULL,
    branch_id integer,
    balance_debit numeric(15,2) NOT NULL,
    balance_credit numeric(15,2) NOT NULL,
    balance numeric(15,2) NOT NULL,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.accounts OWNER TO "khaleelal-mulla";

--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO "khaleelal-mulla";

--
-- Name: branches; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.branches (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    location character varying(255) NOT NULL,
    name_ar character varying(100),
    name_en character varying(100),
    branch_code character varying(20),
    branch_type character varying(50),
    is_active boolean NOT NULL,
    description_ar text,
    description_en text,
    phone character varying(20),
    email character varying(100),
    address_ar text,
    address_en text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.branches OWNER TO "khaleelal-mulla";

--
-- Name: branches_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.branches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.branches_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: branches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.branches_id_seq OWNED BY public.branches.id;


--
-- Name: cash_boxes; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.cash_boxes (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name_ar character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    box_type public.cashboxtypeenum NOT NULL,
    branch_id integer NOT NULL,
    user_id integer,
    balance_iqd_cash numeric(15,3) NOT NULL,
    balance_iqd_digital numeric(15,3) NOT NULL,
    balance_usd_cash numeric(15,3) NOT NULL,
    balance_usd_digital numeric(15,3) NOT NULL,
    balance_rmb_cash numeric(15,3) NOT NULL,
    balance_rmb_digital numeric(15,3) NOT NULL,
    is_active boolean NOT NULL,
    description_ar text,
    description_en text,
    last_transaction_date timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    created_by integer
);


ALTER TABLE public.cash_boxes OWNER TO "khaleelal-mulla";

--
-- Name: cash_boxes_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.cash_boxes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cash_boxes_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: cash_boxes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.cash_boxes_id_seq OWNED BY public.cash_boxes.id;


--
-- Name: cash_flow_summaries; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.cash_flow_summaries (
    id integer NOT NULL,
    branch_id integer NOT NULL,
    user_id integer,
    summary_date timestamp without time zone NOT NULL,
    summary_type character varying(20) NOT NULL,
    total_receipts_iqd numeric(15,3),
    total_payments_iqd numeric(15,3),
    total_receipts_usd numeric(15,3),
    total_payments_usd numeric(15,3),
    total_receipts_rmb numeric(15,3),
    total_payments_rmb numeric(15,3),
    net_flow_iqd numeric(15,3),
    net_flow_usd numeric(15,3),
    net_flow_rmb numeric(15,3),
    total_transactions integer,
    total_transfers_sent integer,
    total_transfers_received integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.cash_flow_summaries OWNER TO "khaleelal-mulla";

--
-- Name: cash_flow_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.cash_flow_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cash_flow_summaries_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: cash_flow_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.cash_flow_summaries_id_seq OWNED BY public.cash_flow_summaries.id;


--
-- Name: cash_transactions; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.cash_transactions (
    id integer NOT NULL,
    transaction_number character varying(100) NOT NULL,
    cash_box_id integer NOT NULL,
    transaction_type character varying(50) NOT NULL,
    payment_method public.cashpaymentmethodenum NOT NULL,
    currency_code character varying(3) NOT NULL,
    amount numeric(15,3) NOT NULL,
    reference_type character varying(50),
    reference_id integer,
    reference_number character varying(100),
    description_ar text,
    description_en text,
    notes text,
    customer_id integer,
    customer_name character varying(255),
    transaction_date timestamp without time zone NOT NULL,
    region public.regionenum,
    location_details character varying(500),
    created_at timestamp without time zone NOT NULL,
    created_by integer
);


ALTER TABLE public.cash_transactions OWNER TO "khaleelal-mulla";

--
-- Name: cash_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.cash_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cash_transactions_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: cash_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.cash_transactions_id_seq OWNED BY public.cash_transactions.id;


--
-- Name: cash_transfers; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.cash_transfers (
    id integer NOT NULL,
    transfer_number character varying(100) NOT NULL,
    from_cash_box_id integer NOT NULL,
    to_cash_box_id integer NOT NULL,
    currency_code character varying(3) NOT NULL,
    amount numeric(15,3) NOT NULL,
    payment_method public.cashpaymentmethodenum NOT NULL,
    status public.transferstatusenum NOT NULL,
    description_ar text,
    description_en text,
    transfer_reason character varying(500),
    admin_notes text,
    requested_date timestamp without time zone NOT NULL,
    approved_date timestamp without time zone,
    received_date timestamp without time zone,
    requested_by integer NOT NULL,
    approved_by integer,
    received_by integer,
    transfer_receipt_url character varying(500),
    paper_attachment_url character varying(500),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.cash_transfers OWNER TO "khaleelal-mulla";

--
-- Name: cash_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.cash_transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cash_transfers_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: cash_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.cash_transfers_id_seq OWNED BY public.cash_transfers.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    parent_id integer,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.categories OWNER TO "khaleelal-mulla";

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: chart_of_accounts; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.chart_of_accounts (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name_ar character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    account_type public.accounttypeenum NOT NULL,
    parent_id integer,
    level integer NOT NULL,
    is_active boolean,
    allow_posting boolean,
    description_ar text,
    description_en text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.chart_of_accounts OWNER TO "khaleelal-mulla";

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.chart_of_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chart_of_accounts_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.chart_of_accounts_id_seq OWNED BY public.chart_of_accounts.id;


--
-- Name: currencies; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.currencies (
    id integer NOT NULL,
    code character varying(3) NOT NULL,
    name_ar character varying(100) NOT NULL,
    name_en character varying(100) NOT NULL,
    symbol character varying(10) NOT NULL,
    exchange_rate numeric(15,6) NOT NULL,
    is_base_currency boolean,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.currencies OWNER TO "khaleelal-mulla";

--
-- Name: currencies_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.currencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.currencies_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: currencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.currencies_id_seq OWNED BY public.currencies.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    customer_code character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    company_name character varying(200),
    phone character varying(20),
    email character varying(255),
    address text,
    city character varying(100),
    country character varying(100),
    tax_number character varying(50),
    credit_limit numeric(12,2),
    payment_terms integer,
    discount_percentage numeric(5,2),
    is_active boolean,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    currency character varying(3),
    portal_language character varying(5),
    salesperson_id integer
);


ALTER TABLE public.customers OWNER TO "khaleelal-mulla";

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.exchange_rates (
    id integer NOT NULL,
    from_currency_id integer NOT NULL,
    to_currency_id integer NOT NULL,
    rate numeric(15,6) NOT NULL,
    date timestamp without time zone NOT NULL,
    is_active boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.exchange_rates OWNER TO "khaleelal-mulla";

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.exchange_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exchange_rates_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: exchange_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.exchange_rates_id_seq OWNED BY public.exchange_rates.id;


--
-- Name: fiscal_years; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.fiscal_years (
    id integer NOT NULL,
    name_ar character varying(100) NOT NULL,
    name_en character varying(100) NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    is_current boolean,
    is_closed boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.fiscal_years OWNER TO "khaleelal-mulla";

--
-- Name: fiscal_years_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.fiscal_years_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fiscal_years_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: fiscal_years_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.fiscal_years_id_seq OWNED BY public.fiscal_years.id;


--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.inventory_items (
    id integer NOT NULL,
    product_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    quantity_on_hand numeric(15,3),
    quantity_reserved numeric(15,3),
    quantity_ordered numeric(15,3),
    last_cost numeric(10,2),
    average_cost numeric(10,2),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.inventory_items OWNER TO "khaleelal-mulla";

--
-- Name: inventory_items_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.inventory_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_items_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: inventory_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.inventory_items_id_seq OWNED BY public.inventory_items.id;


--
-- Name: invoice_payments; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.invoice_payments (
    id integer NOT NULL,
    payment_number character varying(100) NOT NULL,
    sales_invoice_id integer,
    purchase_invoice_id integer,
    payment_date date NOT NULL,
    amount numeric(15,2) NOT NULL,
    currency_id integer NOT NULL,
    exchange_rate numeric(10,4) NOT NULL,
    payment_method character varying(50) NOT NULL,
    reference_number character varying(100),
    bank_account character varying(100),
    check_number character varying(50),
    check_date date,
    notes text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.invoice_payments OWNER TO "khaleelal-mulla";

--
-- Name: invoice_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.invoice_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoice_payments_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: invoice_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.invoice_payments_id_seq OWNED BY public.invoice_payments.id;


--
-- Name: item_categories; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.item_categories (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name_ar character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    description_ar text,
    description_en text,
    parent_id integer,
    level integer,
    sort_order integer,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.item_categories OWNER TO "khaleelal-mulla";

--
-- Name: item_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.item_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_categories_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: item_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.item_categories_id_seq OWNED BY public.item_categories.id;


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.journal_entries (
    id integer NOT NULL,
    journal_id integer NOT NULL,
    currency_id integer NOT NULL,
    branch_id integer,
    entry_number character varying(50) NOT NULL,
    reference character varying(100),
    reference_type character varying(50),
    reference_id integer,
    entry_date timestamp without time zone NOT NULL,
    posting_date timestamp without time zone,
    description_ar text,
    description_en text,
    total_debit numeric(15,2) NOT NULL,
    total_credit numeric(15,2) NOT NULL,
    status public.transactionstatusenum NOT NULL,
    posted_by integer,
    posted_at timestamp without time zone,
    created_by integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.journal_entries OWNER TO "khaleelal-mulla";

--
-- Name: journal_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.journal_entries_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: journal_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.journal_entries_id_seq OWNED BY public.journal_entries.id;


--
-- Name: journal_lines; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.journal_lines (
    id integer NOT NULL,
    journal_entry_id integer NOT NULL,
    account_id integer NOT NULL,
    line_number integer NOT NULL,
    description_ar text,
    description_en text,
    debit_amount numeric(15,2) NOT NULL,
    credit_amount numeric(15,2) NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.journal_lines OWNER TO "khaleelal-mulla";

--
-- Name: journal_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.journal_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.journal_lines_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: journal_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.journal_lines_id_seq OWNED BY public.journal_lines.id;


--
-- Name: journals; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.journals (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name_ar character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    journal_type public.journaltypeenum NOT NULL,
    is_active boolean,
    description_ar text,
    description_en text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.journals OWNER TO "khaleelal-mulla";

--
-- Name: journals_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.journals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.journals_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.journals_id_seq OWNED BY public.journals.id;


--
-- Name: migration_batches; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.migration_batches (
    id integer NOT NULL,
    batch_number character varying(50) NOT NULL,
    batch_name character varying(255) NOT NULL,
    description text,
    status public.migrationstatusenum NOT NULL,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    total_entities integer,
    total_records integer,
    successful_records integer,
    failed_records integer,
    source_system character varying(100),
    migration_config text,
    error_log text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    created_by integer
);


ALTER TABLE public.migration_batches OWNER TO "khaleelal-mulla";

--
-- Name: migration_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.migration_batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_batches_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: migration_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.migration_batches_id_seq OWNED BY public.migration_batches.id;


--
-- Name: migration_customers; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.migration_customers (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name_ar character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    email character varying(255),
    phone character varying(20),
    mobile character varying(20),
    address_ar text,
    address_en text,
    city character varying(100),
    region character varying(100),
    postal_code character varying(20),
    country character varying(100),
    tax_number character varying(50),
    currency public.currencyenum NOT NULL,
    credit_limit numeric(15,3),
    payment_terms character varying(100),
    price_list_id integer,
    salesperson_id integer,
    assigned_region character varying(100),
    outstanding_receivable numeric(15,3),
    is_active boolean NOT NULL,
    zoho_customer_id character varying(100),
    zoho_deposit_account character varying(255),
    zoho_last_sync timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.migration_customers OWNER TO "khaleelal-mulla";

--
-- Name: migration_customers_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.migration_customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_customers_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: migration_customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.migration_customers_id_seq OWNED BY public.migration_customers.id;


--
-- Name: migration_items; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.migration_items (
    id integer NOT NULL,
    code character varying(100) NOT NULL,
    name_ar character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    description_ar text,
    description_en text,
    category_id integer,
    brand character varying(100),
    model character varying(100),
    specifications text,
    unit_of_measure character varying(50),
    cost_price_usd numeric(15,3),
    cost_price_iqd numeric(15,3),
    selling_price_usd numeric(15,3),
    selling_price_iqd numeric(15,3),
    track_inventory boolean,
    reorder_level numeric(10,3),
    reorder_quantity numeric(10,3),
    weight numeric(10,3),
    dimensions character varying(100),
    is_active boolean NOT NULL,
    is_serialized boolean,
    is_batch_tracked boolean,
    zoho_item_id character varying(100),
    zoho_last_sync timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    created_by integer
);


ALTER TABLE public.migration_items OWNER TO "khaleelal-mulla";

--
-- Name: migration_items_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.migration_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_items_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: migration_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.migration_items_id_seq OWNED BY public.migration_items.id;


--
-- Name: migration_records; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.migration_records (
    id integer NOT NULL,
    batch_id integer NOT NULL,
    entity_type character varying(100) NOT NULL,
    source_id character varying(100) NOT NULL,
    source_data text,
    target_id integer,
    status public.migrationstatusenum NOT NULL,
    processed_at timestamp without time zone,
    error_message text,
    retry_count integer,
    requires_manual_review boolean,
    manual_review_notes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.migration_records OWNER TO "khaleelal-mulla";

--
-- Name: migration_records_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.migration_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_records_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: migration_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.migration_records_id_seq OWNED BY public.migration_records.id;


--
-- Name: migration_stock; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.migration_stock (
    id integer NOT NULL,
    item_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    quantity_on_hand numeric(12,3) NOT NULL,
    quantity_reserved numeric(12,3) NOT NULL,
    quantity_available numeric(12,3) NOT NULL,
    average_cost numeric(15,3),
    last_cost numeric(15,3),
    reorder_level numeric(10,3),
    reorder_quantity numeric(10,3),
    max_stock_level numeric(10,3),
    last_movement_date timestamp without time zone,
    last_movement_type character varying(50),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.migration_stock OWNER TO "khaleelal-mulla";

--
-- Name: migration_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.migration_stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_stock_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: migration_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.migration_stock_id_seq OWNED BY public.migration_stock.id;


--
-- Name: migration_vendors; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.migration_vendors (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name_ar character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    email character varying(255),
    phone character varying(20),
    contact_person character varying(255),
    address_ar text,
    address_en text,
    city character varying(100),
    country character varying(100),
    tax_number character varying(50),
    currency public.currencyenum NOT NULL,
    payment_terms character varying(100),
    outstanding_payable numeric(15,3),
    is_active boolean NOT NULL,
    zoho_vendor_id character varying(100),
    zoho_last_sync timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.migration_vendors OWNER TO "khaleelal-mulla";

--
-- Name: migration_vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.migration_vendors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_vendors_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: migration_vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.migration_vendors_id_seq OWNED BY public.migration_vendors.id;


--
-- Name: pos_discounts; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.pos_discounts (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name_ar character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    discount_type character varying(20) NOT NULL,
    discount_value numeric(15,2) NOT NULL,
    min_amount numeric(15,2),
    max_amount numeric(15,2),
    min_quantity integer,
    applicable_products text,
    applicable_categories text,
    valid_from timestamp without time zone,
    valid_to timestamp without time zone,
    usage_limit integer,
    usage_count integer,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.pos_discounts OWNER TO "khaleelal-mulla";

--
-- Name: pos_discounts_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.pos_discounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pos_discounts_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: pos_discounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.pos_discounts_id_seq OWNED BY public.pos_discounts.id;


--
-- Name: pos_payments; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.pos_payments (
    id integer NOT NULL,
    transaction_id integer NOT NULL,
    payment_method public.paymentmethodenum NOT NULL,
    amount numeric(15,2) NOT NULL,
    card_type character varying(50),
    card_last_four character varying(4),
    approval_code character varying(50),
    reference_number character varying(100),
    mobile_number character varying(20),
    mobile_provider character varying(50),
    mobile_reference character varying(100),
    credit_reference character varying(100),
    voucher_code character varying(100),
    voucher_type character varying(50),
    notes text,
    created_at timestamp without time zone
);


ALTER TABLE public.pos_payments OWNER TO "khaleelal-mulla";

--
-- Name: pos_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.pos_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pos_payments_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: pos_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.pos_payments_id_seq OWNED BY public.pos_payments.id;


--
-- Name: pos_promotions; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.pos_promotions (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name_ar character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    description_ar text,
    description_en text,
    promotion_type character varying(50) NOT NULL,
    rules text,
    valid_from timestamp without time zone,
    valid_to timestamp without time zone,
    usage_limit integer,
    usage_count integer,
    priority integer,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.pos_promotions OWNER TO "khaleelal-mulla";

--
-- Name: pos_promotions_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.pos_promotions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pos_promotions_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: pos_promotions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.pos_promotions_id_seq OWNED BY public.pos_promotions.id;


--
-- Name: pos_sessions; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.pos_sessions (
    id integer NOT NULL,
    session_number character varying(50) NOT NULL,
    terminal_id integer NOT NULL,
    currency_id integer NOT NULL,
    user_id integer NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    status public.possessionstatusenum NOT NULL,
    opening_cash_amount numeric(15,2) NOT NULL,
    opening_notes text,
    closing_cash_amount numeric(15,2),
    closing_card_amount numeric(15,2),
    closing_mobile_amount numeric(15,2),
    closing_total_amount numeric(15,2),
    closing_notes text,
    total_sales numeric(15,2),
    total_refunds numeric(15,2),
    total_discounts numeric(15,2),
    total_tax numeric(15,2),
    transaction_count integer,
    closed_by integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.pos_sessions OWNER TO "khaleelal-mulla";

--
-- Name: pos_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.pos_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pos_sessions_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: pos_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.pos_sessions_id_seq OWNED BY public.pos_sessions.id;


--
-- Name: pos_terminals; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.pos_terminals (
    id integer NOT NULL,
    terminal_code character varying(50) NOT NULL,
    name_ar character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    branch_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    receipt_printer character varying(255),
    barcode_scanner character varying(255),
    cash_drawer character varying(255),
    display character varying(255),
    default_tax_rate numeric(5,2),
    allow_discount boolean,
    max_discount_percent numeric(5,2),
    allow_negative_stock boolean,
    auto_print_receipt boolean,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.pos_terminals OWNER TO "khaleelal-mulla";

--
-- Name: pos_terminals_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.pos_terminals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pos_terminals_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: pos_terminals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.pos_terminals_id_seq OWNED BY public.pos_terminals.id;


--
-- Name: pos_transaction_items; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.pos_transaction_items (
    id integer NOT NULL,
    transaction_id integer NOT NULL,
    product_id integer NOT NULL,
    line_number integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    unit_price numeric(15,2) NOT NULL,
    discount_amount numeric(15,2) NOT NULL,
    discount_percent numeric(5,2) NOT NULL,
    tax_amount numeric(15,2) NOT NULL,
    tax_percent numeric(5,2) NOT NULL,
    line_total numeric(15,2) NOT NULL,
    notes text,
    created_at timestamp without time zone
);


ALTER TABLE public.pos_transaction_items OWNER TO "khaleelal-mulla";

--
-- Name: pos_transaction_items_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.pos_transaction_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pos_transaction_items_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: pos_transaction_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.pos_transaction_items_id_seq OWNED BY public.pos_transaction_items.id;


--
-- Name: pos_transactions; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.pos_transactions (
    id integer NOT NULL,
    transaction_number character varying(50) NOT NULL,
    terminal_id integer NOT NULL,
    session_id integer NOT NULL,
    customer_id integer,
    sales_order_id integer,
    transaction_type public.postransactiontypeenum NOT NULL,
    transaction_date timestamp without time zone NOT NULL,
    subtotal numeric(15,2) NOT NULL,
    discount_amount numeric(15,2) NOT NULL,
    discount_percent numeric(5,2) NOT NULL,
    tax_amount numeric(15,2) NOT NULL,
    tax_percent numeric(5,2) NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    amount_paid numeric(15,2) NOT NULL,
    change_amount numeric(15,2) NOT NULL,
    receipt_number character varying(50),
    notes text,
    void_reason character varying(255),
    voided_at timestamp without time zone,
    voided_by integer,
    cashier_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.pos_transactions OWNER TO "khaleelal-mulla";

--
-- Name: pos_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.pos_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pos_transactions_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: pos_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.pos_transactions_id_seq OWNED BY public.pos_transactions.id;


--
-- Name: price_list_items; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.price_list_items (
    id integer NOT NULL,
    price_list_id integer NOT NULL,
    item_id integer NOT NULL,
    unit_price numeric(15,3) NOT NULL,
    discount_percentage numeric(5,2),
    minimum_quantity numeric(10,3),
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.price_list_items OWNER TO "khaleelal-mulla";

--
-- Name: price_list_items_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.price_list_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.price_list_items_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: price_list_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.price_list_items_id_seq OWNED BY public.price_list_items.id;


--
-- Name: price_lists; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.price_lists (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name_ar character varying(255) NOT NULL,
    name_en character varying(255) NOT NULL,
    description_ar text,
    description_en text,
    currency public.currencyenum NOT NULL,
    is_default boolean,
    is_active boolean NOT NULL,
    effective_from timestamp without time zone,
    effective_to timestamp without time zone,
    zoho_price_list_id character varying(100),
    zoho_last_sync timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    created_by integer
);


ALTER TABLE public.price_lists OWNER TO "khaleelal-mulla";

--
-- Name: price_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.price_lists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.price_lists_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: price_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.price_lists_id_seq OWNED BY public.price_lists.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.products (
    id integer NOT NULL,
    sku character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    category_id integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    cost_price numeric(10,2),
    unit_of_measure character varying(50) NOT NULL,
    min_stock_level integer,
    max_stock_level integer,
    reorder_point integer,
    barcode character varying(100),
    is_active boolean,
    is_trackable boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.products OWNER TO "khaleelal-mulla";

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: purchase_invoice_items; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.purchase_invoice_items (
    id integer NOT NULL,
    invoice_id integer NOT NULL,
    product_id integer NOT NULL,
    purchase_item_id integer,
    quantity numeric(15,3) NOT NULL,
    unit_cost numeric(10,2) NOT NULL,
    discount_percentage numeric(5,2),
    discount_amount numeric(10,2),
    line_total numeric(12,2) NOT NULL,
    description text,
    notes text
);


ALTER TABLE public.purchase_invoice_items OWNER TO "khaleelal-mulla";

--
-- Name: purchase_invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.purchase_invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_invoice_items_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: purchase_invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.purchase_invoice_items_id_seq OWNED BY public.purchase_invoice_items.id;


--
-- Name: purchase_invoices; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.purchase_invoices (
    id integer NOT NULL,
    invoice_number character varying(100) NOT NULL,
    supplier_invoice_number character varying(100),
    supplier_id integer NOT NULL,
    purchase_order_id integer,
    branch_id integer NOT NULL,
    warehouse_id integer,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    received_date date,
    currency_id integer NOT NULL,
    exchange_rate numeric(10,4) NOT NULL,
    invoice_type public.invoicetypeenum NOT NULL,
    status public.invoicestatusenum NOT NULL,
    payment_terms public.paymenttermsenum NOT NULL,
    subtotal numeric(15,2) NOT NULL,
    discount_percentage numeric(5,2),
    discount_amount numeric(15,2),
    tax_percentage numeric(5,2),
    tax_amount numeric(15,2),
    shipping_amount numeric(15,2),
    total_amount numeric(15,2) NOT NULL,
    paid_amount numeric(15,2),
    notes text,
    internal_notes text,
    payment_method character varying(50),
    reference_number character varying(100),
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    received_at timestamp with time zone,
    cancelled_at timestamp with time zone
);


ALTER TABLE public.purchase_invoices OWNER TO "khaleelal-mulla";

--
-- Name: purchase_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.purchase_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_invoices_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: purchase_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.purchase_invoices_id_seq OWNED BY public.purchase_invoices.id;


--
-- Name: purchase_items; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.purchase_items (
    id integer NOT NULL,
    purchase_order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity numeric(15,3) NOT NULL,
    unit_cost numeric(10,2) NOT NULL,
    discount_percentage numeric(5,2),
    discount_amount numeric(10,2),
    line_total numeric(12,2) NOT NULL,
    received_quantity numeric(15,3),
    notes text
);


ALTER TABLE public.purchase_items OWNER TO "khaleelal-mulla";

--
-- Name: purchase_items_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.purchase_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_items_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: purchase_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.purchase_items_id_seq OWNED BY public.purchase_items.id;


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.purchase_orders (
    id integer NOT NULL,
    order_number character varying(50) NOT NULL,
    supplier_id integer NOT NULL,
    branch_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    order_date date NOT NULL,
    expected_delivery_date date,
    actual_delivery_date date,
    status character varying(50),
    payment_status character varying(50),
    payment_method character varying(50),
    subtotal numeric(12,2),
    discount_percentage numeric(5,2),
    discount_amount numeric(12,2),
    tax_percentage numeric(5,2),
    tax_amount numeric(12,2),
    total_amount numeric(12,2),
    paid_amount numeric(12,2),
    notes text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.purchase_orders OWNER TO "khaleelal-mulla";

--
-- Name: purchase_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.purchase_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_orders_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: purchase_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.purchase_orders_id_seq OWNED BY public.purchase_orders.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.roles OWNER TO "khaleelal-mulla";

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sales_invoice_items; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.sales_invoice_items (
    id integer NOT NULL,
    invoice_id integer NOT NULL,
    product_id integer NOT NULL,
    sales_item_id integer,
    quantity numeric(15,3) NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    discount_percentage numeric(5,2),
    discount_amount numeric(10,2),
    line_total numeric(12,2) NOT NULL,
    description text,
    notes text
);


ALTER TABLE public.sales_invoice_items OWNER TO "khaleelal-mulla";

--
-- Name: sales_invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.sales_invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_invoice_items_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: sales_invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.sales_invoice_items_id_seq OWNED BY public.sales_invoice_items.id;


--
-- Name: sales_invoices; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.sales_invoices (
    id integer NOT NULL,
    invoice_number character varying(100) NOT NULL,
    customer_id integer NOT NULL,
    sales_order_id integer,
    branch_id integer NOT NULL,
    warehouse_id integer,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    currency_id integer NOT NULL,
    exchange_rate numeric(10,4) NOT NULL,
    invoice_type public.invoicetypeenum NOT NULL,
    status public.invoicestatusenum NOT NULL,
    payment_terms public.paymenttermsenum NOT NULL,
    subtotal numeric(15,2) NOT NULL,
    discount_percentage numeric(5,2),
    discount_amount numeric(15,2),
    tax_percentage numeric(5,2),
    tax_amount numeric(15,2),
    shipping_amount numeric(15,2),
    total_amount numeric(15,2) NOT NULL,
    paid_amount numeric(15,2),
    notes text,
    internal_notes text,
    payment_method character varying(50),
    reference_number character varying(100),
    is_recurring boolean,
    recurring_frequency character varying(20),
    parent_invoice_id integer,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    issued_at timestamp with time zone,
    cancelled_at timestamp with time zone
);


ALTER TABLE public.sales_invoices OWNER TO "khaleelal-mulla";

--
-- Name: sales_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.sales_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_invoices_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: sales_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.sales_invoices_id_seq OWNED BY public.sales_invoices.id;


--
-- Name: sales_items; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.sales_items (
    id integer NOT NULL,
    sales_order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity numeric(15,3) NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    discount_percentage numeric(5,2),
    discount_amount numeric(10,2),
    line_total numeric(12,2) NOT NULL,
    delivered_quantity numeric(15,3),
    notes text
);


ALTER TABLE public.sales_items OWNER TO "khaleelal-mulla";

--
-- Name: sales_items_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.sales_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_items_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: sales_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.sales_items_id_seq OWNED BY public.sales_items.id;


--
-- Name: sales_orders; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.sales_orders (
    id integer NOT NULL,
    order_number character varying(50) NOT NULL,
    customer_id integer NOT NULL,
    branch_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    order_date date NOT NULL,
    expected_delivery_date date,
    actual_delivery_date date,
    status character varying(50),
    payment_status character varying(50),
    payment_method character varying(50),
    subtotal numeric(12,2),
    discount_percentage numeric(5,2),
    discount_amount numeric(12,2),
    tax_percentage numeric(5,2),
    tax_amount numeric(12,2),
    total_amount numeric(12,2),
    paid_amount numeric(12,2),
    notes text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.sales_orders OWNER TO "khaleelal-mulla";

--
-- Name: sales_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.sales_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_orders_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: sales_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.sales_orders_id_seq OWNED BY public.sales_orders.id;


--
-- Name: salesperson_regions; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.salesperson_regions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    region public.regionenum NOT NULL,
    is_primary boolean NOT NULL,
    is_active boolean NOT NULL,
    assigned_date timestamp without time zone NOT NULL,
    created_at timestamp without time zone NOT NULL,
    assigned_by integer
);


ALTER TABLE public.salesperson_regions OWNER TO "khaleelal-mulla";

--
-- Name: salesperson_regions_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.salesperson_regions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.salesperson_regions_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: salesperson_regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.salesperson_regions_id_seq OWNED BY public.salesperson_regions.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    inventory_item_id integer NOT NULL,
    movement_type character varying(50) NOT NULL,
    reference_type character varying(50),
    reference_id integer,
    quantity numeric(15,3) NOT NULL,
    unit_cost numeric(10,2),
    notes text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.stock_movements OWNER TO "khaleelal-mulla";

--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_movements_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    supplier_code character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    company_name character varying(200),
    phone character varying(20),
    email character varying(255),
    address text,
    city character varying(100),
    country character varying(100),
    tax_number character varying(50),
    payment_terms integer,
    is_active boolean,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.suppliers OWNER TO "khaleelal-mulla";

--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.suppliers_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    role_id integer NOT NULL,
    branch_id integer NOT NULL,
    employee_code character varying(20),
    phone character varying(20),
    is_salesperson boolean NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    last_login timestamp without time zone
);


ALTER TABLE public.users OWNER TO "khaleelal-mulla";

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: khaleelal-mulla
--

CREATE TABLE public.warehouses (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    branch_id integer NOT NULL
);


ALTER TABLE public.warehouses OWNER TO "khaleelal-mulla";

--
-- Name: warehouses_id_seq; Type: SEQUENCE; Schema: public; Owner: khaleelal-mulla
--

CREATE SEQUENCE public.warehouses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.warehouses_id_seq OWNER TO "khaleelal-mulla";

--
-- Name: warehouses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: khaleelal-mulla
--

ALTER SEQUENCE public.warehouses_id_seq OWNED BY public.warehouses.id;


--
-- Name: accounting_periods id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.accounting_periods ALTER COLUMN id SET DEFAULT nextval('public.accounting_periods_id_seq'::regclass);


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: branches id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.branches ALTER COLUMN id SET DEFAULT nextval('public.branches_id_seq'::regclass);


--
-- Name: cash_boxes id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_boxes ALTER COLUMN id SET DEFAULT nextval('public.cash_boxes_id_seq'::regclass);


--
-- Name: cash_flow_summaries id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_flow_summaries ALTER COLUMN id SET DEFAULT nextval('public.cash_flow_summaries_id_seq'::regclass);


--
-- Name: cash_transactions id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transactions ALTER COLUMN id SET DEFAULT nextval('public.cash_transactions_id_seq'::regclass);


--
-- Name: cash_transfers id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transfers ALTER COLUMN id SET DEFAULT nextval('public.cash_transfers_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: chart_of_accounts id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.chart_of_accounts ALTER COLUMN id SET DEFAULT nextval('public.chart_of_accounts_id_seq'::regclass);


--
-- Name: currencies id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.currencies ALTER COLUMN id SET DEFAULT nextval('public.currencies_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: exchange_rates id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.exchange_rates ALTER COLUMN id SET DEFAULT nextval('public.exchange_rates_id_seq'::regclass);


--
-- Name: fiscal_years id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.fiscal_years ALTER COLUMN id SET DEFAULT nextval('public.fiscal_years_id_seq'::regclass);


--
-- Name: inventory_items id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.inventory_items ALTER COLUMN id SET DEFAULT nextval('public.inventory_items_id_seq'::regclass);


--
-- Name: invoice_payments id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.invoice_payments ALTER COLUMN id SET DEFAULT nextval('public.invoice_payments_id_seq'::regclass);


--
-- Name: item_categories id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.item_categories ALTER COLUMN id SET DEFAULT nextval('public.item_categories_id_seq'::regclass);


--
-- Name: journal_entries id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journal_entries ALTER COLUMN id SET DEFAULT nextval('public.journal_entries_id_seq'::regclass);


--
-- Name: journal_lines id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journal_lines ALTER COLUMN id SET DEFAULT nextval('public.journal_lines_id_seq'::regclass);


--
-- Name: journals id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journals ALTER COLUMN id SET DEFAULT nextval('public.journals_id_seq'::regclass);


--
-- Name: migration_batches id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_batches ALTER COLUMN id SET DEFAULT nextval('public.migration_batches_id_seq'::regclass);


--
-- Name: migration_customers id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_customers ALTER COLUMN id SET DEFAULT nextval('public.migration_customers_id_seq'::regclass);


--
-- Name: migration_items id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_items ALTER COLUMN id SET DEFAULT nextval('public.migration_items_id_seq'::regclass);


--
-- Name: migration_records id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_records ALTER COLUMN id SET DEFAULT nextval('public.migration_records_id_seq'::regclass);


--
-- Name: migration_stock id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_stock ALTER COLUMN id SET DEFAULT nextval('public.migration_stock_id_seq'::regclass);


--
-- Name: migration_vendors id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_vendors ALTER COLUMN id SET DEFAULT nextval('public.migration_vendors_id_seq'::regclass);


--
-- Name: pos_discounts id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_discounts ALTER COLUMN id SET DEFAULT nextval('public.pos_discounts_id_seq'::regclass);


--
-- Name: pos_payments id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_payments ALTER COLUMN id SET DEFAULT nextval('public.pos_payments_id_seq'::regclass);


--
-- Name: pos_promotions id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_promotions ALTER COLUMN id SET DEFAULT nextval('public.pos_promotions_id_seq'::regclass);


--
-- Name: pos_sessions id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_sessions ALTER COLUMN id SET DEFAULT nextval('public.pos_sessions_id_seq'::regclass);


--
-- Name: pos_terminals id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_terminals ALTER COLUMN id SET DEFAULT nextval('public.pos_terminals_id_seq'::regclass);


--
-- Name: pos_transaction_items id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transaction_items ALTER COLUMN id SET DEFAULT nextval('public.pos_transaction_items_id_seq'::regclass);


--
-- Name: pos_transactions id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transactions ALTER COLUMN id SET DEFAULT nextval('public.pos_transactions_id_seq'::regclass);


--
-- Name: price_list_items id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.price_list_items ALTER COLUMN id SET DEFAULT nextval('public.price_list_items_id_seq'::regclass);


--
-- Name: price_lists id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.price_lists ALTER COLUMN id SET DEFAULT nextval('public.price_lists_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: purchase_invoice_items id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoice_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_invoice_items_id_seq'::regclass);


--
-- Name: purchase_invoices id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoices ALTER COLUMN id SET DEFAULT nextval('public.purchase_invoices_id_seq'::regclass);


--
-- Name: purchase_items id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_items_id_seq'::regclass);


--
-- Name: purchase_orders id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_orders ALTER COLUMN id SET DEFAULT nextval('public.purchase_orders_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sales_invoice_items id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoice_items ALTER COLUMN id SET DEFAULT nextval('public.sales_invoice_items_id_seq'::regclass);


--
-- Name: sales_invoices id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoices ALTER COLUMN id SET DEFAULT nextval('public.sales_invoices_id_seq'::regclass);


--
-- Name: sales_items id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_items ALTER COLUMN id SET DEFAULT nextval('public.sales_items_id_seq'::regclass);


--
-- Name: sales_orders id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_orders ALTER COLUMN id SET DEFAULT nextval('public.sales_orders_id_seq'::regclass);


--
-- Name: salesperson_regions id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.salesperson_regions ALTER COLUMN id SET DEFAULT nextval('public.salesperson_regions_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: warehouses id; Type: DEFAULT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN id SET DEFAULT nextval('public.warehouses_id_seq'::regclass);


--
-- Data for Name: accounting_periods; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.accounting_periods (id, fiscal_year_id, name_ar, name_en, start_date, end_date, is_closed, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.accounts (id, chart_account_id, currency_id, branch_id, balance_debit, balance_credit, balance, is_active, created_at, updated_at) FROM stdin;
1	2	1	\N	0.00	0.00	0.00	t	2025-06-24 18:12:26.71019	2025-06-24 18:12:26.710193
2	2	1	\N	0.00	0.00	0.00	t	2025-06-24 18:12:42.175748	2025-06-24 18:12:42.17575
3	2	1	\N	0.00	0.00	0.00	t	2025-06-24 18:13:43.003288	2025-06-24 18:13:43.003291
4	2	1	\N	0.00	0.00	0.00	t	2025-06-27 21:11:04.943059	2025-06-27 21:11:04.943065
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.alembic_version (version_num) FROM stdin;
9d2d52e3d8a3
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.branches (id, name, location, name_ar, name_en, branch_code, branch_type, is_active, description_ar, description_en, phone, email, address_ar, address_en, created_at, updated_at) FROM stdin;
1	الفرع الرئيسي	الرياض، المملكة العربية السعودية	\N	\N	\N	MAIN_BRANCH	t	\N	\N	\N	\N	\N	\N	2025-06-25 23:15:54.750205	2025-06-25 20:21:31.640145
2	Main Wholesale Branch	Main Wholesale Location, Baghdad, Iraq	\N	\N	\N	MAIN_WHOLESALE	t	\N	\N	\N	\N	\N	\N	2025-06-25 23:15:54.750205	2025-06-25 20:21:31.640147
3	TSH Dora Branch	Dora District, Baghdad, Iraq	\N	\N	\N	DORA_BRANCH	t	\N	\N	\N	\N	\N	\N	2025-06-25 23:15:54.750205	2025-06-25 20:21:31.640147
4	Main Branch	Baghdad, Iraq	الفرع الرئيسي	Main Branch	MAIN	MAIN_WHOLESALE	t	الفرع الرئيسي لتجارة الجملة	Main wholesale branch	+964-xxx-xxxx	main@tsh-erp.com	\N	\N	2025-06-26 18:04:35.773263	2025-06-26 18:04:35.773266
5	Dora Branch	Dora, Baghdad	فرع الدورة	Dora Branch	DORA	DORA_BRANCH	t	فرع الدورة للبيع بالتجزئة	Dora retail branch	+964-xxx-yyyy	dora@tsh-erp.com	\N	\N	2025-06-26 18:04:35.773266	2025-06-26 18:04:35.773267
\.


--
-- Data for Name: cash_boxes; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.cash_boxes (id, code, name_ar, name_en, box_type, branch_id, user_id, balance_iqd_cash, balance_iqd_digital, balance_usd_cash, balance_usd_digital, balance_rmb_cash, balance_rmb_digital, is_active, description_ar, description_en, last_transaction_date, created_at, updated_at, created_by) FROM stdin;
1	CB-MWB-001	صندوق الفرع الرئيسي	Main Wholesale Branch Cash Box	BRANCH	1	\N	5000000.000	2000000.000	15000.000	10000.000	0.000	0.000	t	الصندوق الرئيسي للفرع الأساسي	Main cash box for wholesale branch	\N	2025-06-25 20:20:02.167917	2025-06-25 20:20:02.167919	1
2	CB-DRA-001	صندوق فرع الدورة	Dora Branch Cash Box	BRANCH	2	\N	2000000.000	500000.000	5000.000	3000.000	0.000	0.000	t	صندوق فرع الدورة	Dora branch cash box	\N	2025-06-25 20:22:10.338973	2025-06-25 20:22:10.338975	1
3	CB-SP-001-AYAD	صندوق أياد البغدادي	Ayad Al-Baghdadi Cash Box	SALESPERSON	1	7	700000.000	100000.000	2000.000	500.000	0.000	0.000	t	صندوق مندوب المبيعات أياد البغدادي - مناطق كربلاء والنجف وبابل	Ayad Al-Baghdadi salesperson cash box - Karbala, Najaf, Babel regions	2025-06-25 20:28:07.180681	2025-06-25 20:23:59.377367	2025-06-25 20:28:07.180682	1
\.


--
-- Data for Name: cash_flow_summaries; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.cash_flow_summaries (id, branch_id, user_id, summary_date, summary_type, total_receipts_iqd, total_payments_iqd, total_receipts_usd, total_payments_usd, total_receipts_rmb, total_payments_rmb, net_flow_iqd, net_flow_usd, net_flow_rmb, total_transactions, total_transfers_sent, total_transfers_received, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cash_transactions; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.cash_transactions (id, transaction_number, cash_box_id, transaction_type, payment_method, currency_code, amount, reference_type, reference_id, reference_number, description_ar, description_en, notes, customer_id, customer_name, transaction_date, region, location_details, created_at, created_by) FROM stdin;
1	RCP-20250625-0001	3	RECEIPT	CASH	IQD	150000.000	\N	\N	REF-001	استلام نقدي من عميل	Cash receipt from customer	دفعة أولى من فاتورة 12345	\N	أحمد محمد	2025-06-25 20:25:00	\N	\N	2025-06-25 20:24:42.184575	1
2	RCP-20250625-0002	3	RECEIPT	CASH	IQD	50000.000	\N	\N	\N	\N	\N	Quick cash receipt	\N	Mohammed Ali	2025-06-25 20:28:07.178618	\N	\N	2025-06-25 20:28:07.179986	1
\.


--
-- Data for Name: cash_transfers; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.cash_transfers (id, transfer_number, from_cash_box_id, to_cash_box_id, currency_code, amount, payment_method, status, description_ar, description_en, transfer_reason, admin_notes, requested_date, approved_date, received_date, requested_by, approved_by, received_by, transfer_receipt_url, paper_attachment_url, created_at, updated_at) FROM stdin;
1	TRF-20250625-0001	1	3	IQD	100000.000	CASH	RECEIVED	تحويل نقدي من الفرع الرئيسي إلى مندوب المبيعات	Cash transfer from main branch to salesperson	\N	تم الموافقة على التحويل	2025-06-25 20:25:07.967427	2025-06-25 20:26:56.914337	2025-06-25 20:27:10.406751	1	1	1	\N	\N	2025-06-25 20:25:07.967428	2025-06-25 20:27:10.407056
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.categories (id, name, description, parent_id, is_active, created_at, updated_at) FROM stdin;
1	إلكترونيات	أجهزة إلكترونية ومعدات تقنية	\N	t	2025-06-24 20:36:31.729983+03	\N
2	أجهزة كمبيوتر	أجهزة كمبيوتر وملحقاتها	\N	t	2025-06-24 20:51:09.62278+03	\N
\.


--
-- Data for Name: chart_of_accounts; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.chart_of_accounts (id, code, name_ar, name_en, account_type, parent_id, level, is_active, allow_posting, description_ar, description_en, created_at, updated_at) FROM stdin;
2	STD	دليل الحسابات المعياري	Standard Chart of Accounts	ASSET	\N	1	t	t	دليل الحسابات المعياري لنظام TSH ERP	Standard chart of accounts for TSH ERP	2025-06-24 18:12:26.705748	2025-06-24 18:12:26.70575
3	1000	الأصول	Assets	ASSET	\N	1	t	f	\N	\N	2025-06-24 21:56:58.613501	2025-06-24 21:56:58.613502
9	2000	الخصوم	Liabilities	LIABILITY	\N	1	t	f	\N	\N	2025-06-24 21:56:58.623245	2025-06-24 21:56:58.623246
13	3000	حقوق الملكية	Equity	EQUITY	\N	1	t	f	\N	\N	2025-06-24 21:56:58.628396	2025-06-24 21:56:58.628397
16	4000	الإيرادات	Revenue	REVENUE	\N	1	t	f	\N	\N	2025-06-24 21:56:58.63202	2025-06-24 21:56:58.63202
19	5000	المصروفات	Expenses	EXPENSE	\N	1	t	f	\N	\N	2025-06-24 21:56:58.6355	2025-06-24 21:56:58.635501
4	1100	الأصول المتداولة	Current Assets	ASSET	3	2	t	f	\N	\N	2025-06-24 21:56:58.616819	2025-06-24 21:56:58.651236
5	1110	النقدية في الصندوق	Cash in Hand	ASSET	4	3	t	t	\N	\N	2025-06-24 21:56:58.618359	2025-06-24 21:56:58.651237
6	1120	البنك	Bank	ASSET	4	3	t	t	\N	\N	2025-06-24 21:56:58.619624	2025-06-24 21:56:58.651237
7	1130	العملاء والذمم المدينة	Accounts Receivable	ASSET	4	3	t	t	\N	\N	2025-06-24 21:56:58.620856	2025-06-24 21:56:58.651237
8	1140	المخزون	Inventory	ASSET	4	3	t	t	\N	\N	2025-06-24 21:56:58.621871	2025-06-24 21:56:58.651238
10	2100	الخصوم المتداولة	Current Liabilities	LIABILITY	9	2	t	f	\N	\N	2025-06-24 21:56:58.624576	2025-06-24 21:56:58.651238
11	2110	الموردون والذمم الدائنة	Accounts Payable	LIABILITY	10	3	t	t	\N	\N	2025-06-24 21:56:58.626007	2025-06-24 21:56:58.651238
12	2120	الضرائب المستحقة	Accrued Taxes	LIABILITY	10	3	t	t	\N	\N	2025-06-24 21:56:58.627231	2025-06-24 21:56:58.651238
14	3100	رأس المال	Capital	EQUITY	13	2	t	t	\N	\N	2025-06-24 21:56:58.629848	2025-06-24 21:56:58.651238
15	3200	الأرباح المحتجزة	Retained Earnings	EQUITY	13	2	t	t	\N	\N	2025-06-24 21:56:58.630823	2025-06-24 21:56:58.651239
17	4100	مبيعات البضائع	Sales Revenue	REVENUE	16	2	t	t	\N	\N	2025-06-24 21:56:58.633155	2025-06-24 21:56:58.651239
18	4200	إيرادات أخرى	Other Revenue	REVENUE	16	2	t	t	\N	\N	2025-06-24 21:56:58.634271	2025-06-24 21:56:58.651239
20	5100	تكلفة البضاعة المباعة	Cost of Goods Sold	EXPENSE	19	2	t	t	\N	\N	2025-06-24 21:56:58.636687	2025-06-24 21:56:58.651239
21	5200	مصروفات التشغيل	Operating Expenses	EXPENSE	19	2	t	f	\N	\N	2025-06-24 21:56:58.637803	2025-06-24 21:56:58.651239
22	5210	رواتب ومكافآت	Salaries and Benefits	EXPENSE	21	3	t	t	\N	\N	2025-06-24 21:56:58.638795	2025-06-24 21:56:58.651239
23	5220	إيجار	Rent Expense	EXPENSE	21	3	t	t	\N	\N	2025-06-24 21:56:58.639914	2025-06-24 21:56:58.65124
24	5230	مصروفات نقل وشحن	Transportation and Shipping	EXPENSE	21	3	t	t	\N	\N	2025-06-24 21:56:58.641482	2025-06-24 21:56:58.65124
\.


--
-- Data for Name: currencies; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.currencies (id, code, name_ar, name_en, symbol, exchange_rate, is_base_currency, is_active, created_at, updated_at) FROM stdin;
1	IQD	دينار عراقي	Iraqi Dinar	ع.د	1.000000	t	t	2025-06-24 18:11:10.229142	2025-06-24 18:11:10.229144
2	USD	دولار أمريكي	US Dollar	$	1310.000000	f	t	2025-06-24 18:11:10.229145	2025-06-24 18:11:10.229145
3	RMB	يوان صيني	Chinese Yuan Renminbi	¥	189.000000	f	t	2025-06-24 18:11:10.229145	2025-06-24 18:11:10.229145
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.customers (id, customer_code, name, company_name, phone, email, address, city, country, tax_number, credit_limit, payment_terms, discount_percentage, is_active, notes, created_at, updated_at, currency, portal_language, salesperson_id) FROM stdin;
2	CUST-002	فاطمة علي	شركة النور للتجارة	+966509876543	fatima@alnour.com	\N	\N	\N	\N	5000.00	30	5.00	t	\N	2025-06-24 20:52:42.214549+03	\N	\N	\N	\N
3	TEST001	Updated Test Customer	Test Company	+964123456789	test@example.com	Test Address	Erbil	Iraq	\N	10000.00	30	5.00	f	\N	2025-06-26 22:27:41.757041+03	2025-06-26 22:27:41.814614+03	\N	\N	\N
4	CUST-003	Erbil Trading LLC	Erbil Trading LLC	+964-66-2222222	sales@erbil-trading.com	Downtown, Erbil	Erbil	Iraq	\N	75000.00	45	15.00	t	Import/Export company	2025-06-26 22:28:27.581037+03	\N	\N	\N	\N
5	CUST-004	Basra Oil Services	Basra Oil Services Ltd.	+964-40-5555555	procurement@basra-oil.com	Industrial Zone, Basra	Basra	Iraq	\N	100000.00	60	8.00	t	Oil industry supplier	2025-06-26 22:28:27.625288+03	\N	\N	\N	\N
6	CUST-005	Najaf Construction	Najaf Construction Co.	+964-33-8888888	projects@najaf-const.com	Industrial Area, Najaf	Najaf	Iraq	\N	25000.00	30	5.00	t	Construction and building materials	2025-06-26 22:28:27.631073+03	\N	\N	\N	\N
8	TEST-1750966144	Updated Stability Test Customer	Test Company Ltd.	+964-777-123456	test@stability.com	Test Address	Updated Test City	Iraq	\N	20000.00	30	5.00	f	\N	2025-06-26 22:29:04.089854+03	2025-06-26 22:29:04.155857+03	\N	\N	\N
7	CUST-006	Sulaymaniyah Tech Hub	Sulaymaniyah Technology Hub	+964-53-9999999	info@suli-tech.com	Tech District, Sulaymaniyah	Sulaymaniyah	Iraq	\N	40000.00	30	12.00	f	Technology and IT services	2025-06-26 22:28:27.637257+03	2025-06-26 22:30:03.96929+03	\N	\N	\N
1	CUST-001	أحمد محمد	شركة التقنية المتقدمة	+966501234567	ahmed@techcompany.com	\N	\N	\N	\N	10000.00	0	0.00	f	\N	2025-06-24 20:36:31.735614+03	2025-06-26 22:30:43.541199+03	\N	\N	\N
9	ENHANCED-002	Enhanced Test Customer 2	Enhanced Test Company 2	+964-777-ENHANCED2	enhanced2@test.com	Enhanced Test Address 2	Baghdad	Iraq	\N	25000.00	30	10.00	t	\N	2025-06-26 22:45:36.916582+03	\N	USD	ar	7
10	FINAL-TEST-001	خليل الخفاجي	شركة خليل للتجارة	+964-770-888999	khalil@khafaji-trading.com	شارع الرشيد، بغداد	بغداد	العراق	\N	50000.00	45	15.00	t	\N	2025-06-26 22:48:39.554151+03	\N	USD	ar	7
11	1234	خليل الخفاجي								0.00	30	0.00	t		2025-06-26 23:12:06.929095+03	\N	IQD	ar	10
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.exchange_rates (id, from_currency_id, to_currency_id, rate, date, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: fiscal_years; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.fiscal_years (id, name_ar, name_en, start_date, end_date, is_current, is_closed, created_at, updated_at) FROM stdin;
1	السنة المالية 2025	Fiscal Year 2025	2025-01-01 00:00:00	2025-12-31 00:00:00	t	f	2025-06-24 18:12:26.718648	2025-06-24 18:12:26.718648
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.inventory_items (id, product_id, warehouse_id, quantity_on_hand, quantity_reserved, quantity_ordered, last_cost, average_cost, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoice_payments; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.invoice_payments (id, payment_number, sales_invoice_id, purchase_invoice_id, payment_date, amount, currency_id, exchange_rate, payment_method, reference_number, bank_account, check_number, check_date, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: item_categories; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.item_categories (id, code, name_ar, name_en, description_ar, description_en, parent_id, level, sort_order, is_active, created_at, updated_at) FROM stdin;
1	ELECTRONICS	الإلكترونيات	Electronics	الأجهزة الإلكترونية والكهربائية	Electronic and electrical devices	\N	1	10	t	2025-06-26 21:00:47.801144	2025-06-26 21:00:47.801146
2	COMPUTERS	أجهزة الكمبيوتر	Computers	أجهزة الكمبيوتر المحمولة والمكتبية	Laptops, desktops and computer systems	1	2	11	t	2025-06-26 21:00:47.801147	2025-06-26 21:00:47.801147
3	MOBILE	الهواتف المحمولة	Mobile Phones	الهواتف الذكية والأجهزة اللوحية	Smartphones and tablets	1	2	12	t	2025-06-26 21:00:47.801147	2025-06-26 21:00:47.801147
4	ACCESSORIES	الإكسسوارات	Accessories	إكسسوارات الكمبيوتر والهواتف	Computer and phone accessories	\N	1	20	t	2025-06-26 21:00:47.801147	2025-06-26 21:00:47.801148
5	NETWORKING	الشبكات	Networking	معدات الشبكات والاتصالات	Network and communication equipment	\N	1	30	t	2025-06-26 21:00:47.801148	2025-06-26 21:00:47.801148
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.journal_entries (id, journal_id, currency_id, branch_id, entry_number, reference, reference_type, reference_id, entry_date, posting_date, description_ar, description_en, total_debit, total_credit, status, posted_by, posted_at, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: journal_lines; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.journal_lines (id, journal_entry_id, account_id, line_number, description_ar, description_en, debit_amount, credit_amount, created_at) FROM stdin;
\.


--
-- Data for Name: journals; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.journals (id, code, name_ar, name_en, journal_type, is_active, description_ar, description_en, created_at, updated_at) FROM stdin;
1	GJ	دفتر اليومية العام	General Journal	GENERAL	t	دفتر اليومية العام لجميع المعاملات	General journal for all transactions	2025-06-24 18:12:26.714565	2025-06-24 18:12:26.714566
2	SJ	دفتر يومية المبيعات	Sales Journal	SALES	t	دفتر يومية معاملات المبيعات	Journal for sales transactions	2025-06-24 18:12:26.714566	2025-06-24 18:12:26.714566
3	PJ	دفتر يومية المشتريات	Purchase Journal	PURCHASE	t	دفتر يومية معاملات المشتريات	Journal for purchase transactions	2025-06-24 18:12:26.714566	2025-06-24 18:12:26.714566
4	CJ	دفتر يومية النقدية	Cash Journal	CASH	t	دفتر يومية المعاملات النقدية	Journal for cash transactions	2025-06-24 18:12:26.714567	2025-06-24 18:12:26.714567
\.


--
-- Data for Name: migration_batches; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.migration_batches (id, batch_number, batch_name, description, status, start_time, end_time, total_entities, total_records, successful_records, failed_records, source_system, migration_config, error_log, created_at, updated_at, created_by) FROM stdin;
\.


--
-- Data for Name: migration_customers; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.migration_customers (id, code, name_ar, name_en, email, phone, mobile, address_ar, address_en, city, region, postal_code, country, tax_number, currency, credit_limit, payment_terms, price_list_id, salesperson_id, assigned_region, outstanding_receivable, is_active, zoho_customer_id, zoho_deposit_account, zoho_last_sync, created_at, updated_at) FROM stdin;
5	CUST00001	شركة المستقبل للتكنولوجيا	Future Technology Company	info@future-tech.iq	+964-1-234-5678	+964-790-123-4567	حي الجادرية، شارع الجامعة، بناية رقم 15	Al-Jadriya District, University Street, Building No. 15	Baghdad	Baghdad	\N	Iraq	12345678901	USD	25000.000	Net 30	\N	\N	\N	5432.500	t	4000000000001	Sales Deposit - Ahmad Mahmoud	\N	2025-05-12 09:59:08.901092	2025-06-24 09:59:08.901097
6	CUST00002	مؤسسة النور للتجارة العامة	Al-Noor General Trading Est.	sales@alnoor-trading.com	+964-1-987-6543	+964-770-987-6543	منطقة الكرادة، شارع أبو نواس، مجمع الأعمال رقم 8	Karada District, Abu Nawas Street, Business Complex No. 8	Baghdad	Baghdad	\N	Iraq	98765432101	IQD	50000.000	Net 15	\N	\N	\N	12750.000	t	4000000000002	Sales Deposit - Fatima Ali	\N	2025-04-25 09:59:08.901099	2025-06-25 09:59:08.901099
7	CUST00003	شركة بغداد للحاسبات والشبكات	Baghdad Computers & Networks Co.	info@baghdad-computers.net	+964-1-555-0123	+964-750-555-0123	شارع الرشيد، وسط البلد، بناية التجارة الحديثة	Al-Rashid Street, Downtown, Modern Trade Building	Baghdad	Baghdad	\N	Iraq	55512345678	USD	75000.000	Net 45	\N	\N	\N	0.000	t	4000000000003	Sales Deposit - Hassan Omar	\N	2025-05-19 09:59:08.9011	2025-06-26 03:59:08.901101
8	CUST00004	مكتب الإبداع للاستشارات الهندسية	Innovation Engineering Consultancy Office	contact@innovation-eng.iq	+964-1-777-8888	+964-790-777-8888	حي المنصور، شارع الأميرات، مجمع المهندسين	Al-Mansour District, Al-Amirat Street, Engineers Complex	Baghdad	Baghdad	\N	Iraq	77788899901	USD	30000.000	Net 30	\N	\N	\N	8900.750	t	4000000000004	Sales Deposit - Omar Khalil	\N	2025-05-29 09:59:08.901102	2025-06-25 21:59:08.901102
9	CUST00005	شركة الشام للاستيراد والتصدير	Al-Sham Import & Export Company	info@alsham-trade.com	+964-1-444-5555	+964-780-444-5555	منطقة العلوية، شارع حيفا، مركز الأعمال الدولي	Al-Alawiya District, Haifa Street, International Business Center	Baghdad	Baghdad	\N	Iraq	11122334455	USD	100000.000	Net 60	\N	\N	\N	23456.800	t	4000000000005	Sales Deposit - Layla Hassan	\N	2025-05-02 09:59:08.901104	2025-06-26 06:59:08.901104
10	CUST00006	مؤسسة الفجر للصناعات الغذائية	Al-Fajr Food Industries Est.	sales@alfajr-food.iq	+964-1-333-4444	+964-760-333-4444	المنطقة الصناعية، شارع الصناعة، مجمع رقم 12	Industrial Zone, Industry Street, Complex No. 12	Baghdad	Baghdad	\N	Iraq	66677788899	IQD	40000.000	Net 21	\N	\N	\N	15670.250	t	4000000000006	Sales Deposit - Youssef Ali	\N	2025-04-15 09:59:08.901105	2025-06-21 09:59:08.901105
11	CUST00007	شركة الأردن للصيانة والخدمات التقنية	Jordan Technical Maintenance & Services Co.	service@jordan-tech.com	+964-1-666-7777	+964-740-666-7777	حي الصدرية، شارع الخدمات، مركز الصيانة التقنية	Al-Sadriya District, Services Street, Technical Maintenance Center	Baghdad	Baghdad	\N	Iraq	33344455566	USD	20000.000	Net 30	\N	\N	\N	4320.000	f	4000000000007	Sales Deposit - Mariam Saad	\N	2025-03-23 09:59:08.901106	2025-06-11 09:59:08.901106
12	CUST00008	مكتب الخليج للاستشارات المالية	Gulf Financial Consultancy Office	info@gulf-finance.iq	+964-1-888-9999	+964-720-888-9999	حي الجادرية، شارع الجامعة، برج الأعمال الطابق العاشر	Al-Jadriya District, University Street, Business Tower 10th Floor	Baghdad	Baghdad	\N	Iraq	99988877766	USD	15000.000	Net 14	\N	\N	\N	2750.500	t	4000000000008	Sales Deposit - Khalil Ibrahim	\N	2025-06-11 09:59:08.901107	2025-06-26 01:59:08.901107
\.


--
-- Data for Name: migration_items; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.migration_items (id, code, name_ar, name_en, description_ar, description_en, category_id, brand, model, specifications, unit_of_measure, cost_price_usd, cost_price_iqd, selling_price_usd, selling_price_iqd, track_inventory, reorder_level, reorder_quantity, weight, dimensions, is_active, is_serialized, is_batch_tracked, zoho_item_id, zoho_last_sync, created_at, updated_at, created_by) FROM stdin;
1	LAP-001	لاب توب ديل XPS 13	Dell XPS 13 Laptop	لاب توب ديل عالي الأداء بمعالج Intel Core i7	High-performance Dell laptop with Intel Core i7 processor	2	Dell	XPS 13	\N	PCS	800.000	1056000.000	1200.000	1584000.000	t	5.000	10.000	1.200	30.2 x 19.9 x 1.4 cm	t	f	f	\N	\N	2025-06-26 21:00:47.815346	2025-06-26 21:00:47.815348	\N
2	PHN-001	آيفون 15 برو	iPhone 15 Pro	هاتف آبل الذكي الجديد بتقنية A17 Pro	Latest Apple smartphone with A17 Pro chip	3	Apple	iPhone 15 Pro	\N	PCS	900.000	1188000.000	1399.000	1846680.000	t	3.000	5.000	0.187	14.67 x 7.09 x 0.83 cm	t	f	f	\N	\N	2025-06-26 21:00:47.815349	2025-06-26 21:00:47.815349	\N
3	MON-001	شاشة سامسونج 27 بوصة	Samsung 27" Monitor	شاشة سامسونج عالية الدقة 4K	Samsung 4K high-resolution monitor	1	Samsung	M7 27"	\N	PCS	250.000	330000.000	399.000	526680.000	t	2.000	5.000	4.500	61.2 x 36.3 x 20.6 cm	t	f	f	\N	\N	2025-06-26 21:00:47.81535	2025-06-26 21:00:47.81535	\N
4	ACC-001	ماوس لاسلكي لوجيتك	Logitech Wireless Mouse	ماوس لاسلكي عالي الدقة من لوجيتك	High-precision wireless mouse from Logitech	4	Logitech	MX Master 3S	\N	PCS	15.000	19800.000	29.990	39587.000	t	10.000	20.000	0.141	12.4 x 8.4 x 5.1 cm	t	f	f	\N	\N	2025-06-26 21:00:47.81535	2025-06-26 21:00:47.81535	\N
5	NET-001	راوتر TP-Link	TP-Link Router	راوتر لاسلكي عالي السرعة	High-speed wireless router	5	TP-Link	Archer AX50	\N	PCS	75.000	99000.000	129.000	170280.000	t	5.000	10.000	0.680	26.0 x 13.5 x 3.8 cm	t	f	f	\N	\N	2025-06-26 21:00:47.81535	2025-06-26 21:00:47.815351	\N
6	CBL-001	كابل USB-C	USB-C Cable	كابل USB-C عالي الجودة طول متر واحد	High-quality USB-C cable 1 meter length	4	Anker	PowerLine III	\N	PCS	5.000	6600.000	12.990	17147.000	t	20.000	50.000	0.050	100 cm length	t	f	f	\N	\N	2025-06-26 21:00:47.815351	2025-06-26 21:00:47.815351	\N
7	SPH-S23-128GB-BLK	هاتف سامسونغ جالاكسي اس 23 - 128 جيجا - أسود	Samsung Galaxy S23 - 128GB - Black	هاتف ذكي متطور مع كاميرا عالية الدقة وأداء ممتاز	Advanced smartphone with high-resolution camera and excellent performance	3	Samsung	Galaxy S23	{"storage": "128GB", "color": "Black", "camera": "50MP", "battery": "3900mAh", "display": "6.1 inch"}	PCS	650.000	850000.000	799.000	1045000.000	t	5.000	20.000	0.168	146.3 x 70.9 x 7.6 mm	t	t	f	\N	\N	2025-06-26 21:53:56.789049	2025-06-26 21:53:56.789051	\N
8	LTP-XPS13-512GB-SLV	لابتوب ديل اكس بي اس 13 - 512 جيجا - فضي	Dell XPS 13 Laptop - 512GB - Silver	لابتوب عالي الأداء مع معالج Intel Core i7 وذاكرة SSD	High-performance laptop with Intel Core i7 processor and SSD storage	2	Dell	XPS 13	{"processor": "Intel Core i7", "ram": "16GB", "storage": "512GB SSD", "display": "13.3 inch 4K", "color": "Silver"}	PCS	1200.000	1560000.000	1499.000	1950000.000	t	3.000	10.000	1.200	295.7 x 199.2 x 14.8 mm	t	t	f	\N	\N	2025-06-26 21:53:56.789052	2025-06-26 21:53:56.789052	\N
9	HDP-SONY-WH1000XM5	سماعات سوني اللاسلكية مع خاصية إلغاء الضوضاء	Sony WH-1000XM5 Wireless Noise Canceling Headphones	سماعات لاسلكية متطورة مع خاصية إلغاء الضوضاء الذكية	Premium wireless headphones with intelligent noise canceling	4	Sony	WH-1000XM5	{"type": "Over-ear", "connectivity": "Bluetooth 5.2", "battery": "30 hours", "noise_canceling": "Yes"}	PCS	280.000	365000.000	349.000	455000.000	t	10.000	30.000	0.250	Foldable design	t	f	f	\N	\N	2025-06-26 21:53:56.789052	2025-06-26 21:53:56.789052	\N
10	RTR-CISCO-RV340	راوتر سيسكو للشركات الصغيرة	Cisco RV340 Small Business Router	راوتر عالي الأداء للشركات الصغيرة مع خاصية VPN	High-performance small business router with VPN capabilities	5	Cisco	RV340	{"ports": "4x Gigabit Ethernet", "vpn": "IPSec/SSL VPN", "throughput": "900 Mbps", "security": "Firewall"}	PCS	320.000	416000.000	399.000	520000.000	t	5.000	15.000	1.500	200 x 180 x 44 mm	t	t	f	\N	\N	2025-06-26 21:53:56.789053	2025-06-26 21:53:56.789053	\N
11	MON-LG-27UP850	شاشة إل جي 27 بوصة 4K للتصميم	LG 27UP850 27-inch 4K Monitor for Design	شاشة احترافية للتصميم مع دقة 4K ودعم HDR	Professional design monitor with 4K resolution and HDR support	2	LG	27UP850	{"size": "27 inch", "resolution": "3840x2160", "panel": "IPS", "color_gamut": "99% sRGB", "hdr": "HDR10"}	PCS	380.000	495000.000	479.000	625000.000	t	3.000	12.000	5.700	611.4 x 362.8 x 55.1 mm	t	t	f	\N	\N	2025-06-26 21:53:56.789053	2025-06-26 21:53:56.789053	\N
12	KBD-LOGITECH-MX	كيبورد لوجيتك اللاسلكي للمبرمجين	Logitech MX Keys Wireless Keyboard for Programmers	كيبورد لاسلكي متطور مع إضاءة خلفية ذكية	Advanced wireless keyboard with smart backlighting	4	Logitech	MX Keys	{"connectivity": "Bluetooth/USB", "backlight": "Smart illumination", "battery": "10 days", "layout": "Full-size"}	PCS	75.000	97500.000	99.000	129000.000	t	15.000	50.000	0.810	430 x 131 x 20.5 mm	t	f	f	\N	\N	2025-06-26 21:53:56.789053	2025-06-26 21:53:56.789053	\N
13	SSD-SAMSUNG-980PRO-1TB	قرص تخزين SSD سامسونغ 980 برو - 1 تيرا	Samsung 980 PRO SSD - 1TB NVMe	قرص تخزين SSD عالي السرعة للألعاب والتطبيقات الاحترافية	High-speed SSD for gaming and professional applications	2	Samsung	980 PRO	{"capacity": "1TB", "interface": "NVMe PCIe 4.0", "read_speed": "7000 MB/s", "write_speed": "5000 MB/s"}	PCS	120.000	156000.000	149.000	194000.000	t	20.000	50.000	0.008	80.15 x 22.15 x 2.38 mm	t	f	t	\N	\N	2025-06-26 21:53:56.789054	2025-06-26 21:53:56.789054	\N
14	CAM-LOGITECH-C920S	كاميرا ويب لوجيتك بدقة Full HD	Logitech C920S HD Pro Webcam	كاميرا ويب احترافية للاجتماعات والبث المباشر	Professional webcam for meetings and streaming	4	Logitech	C920S	{"resolution": "1080p", "frame_rate": "30fps", "field_of_view": "78°", "autofocus": "Yes", "microphone": "Dual stereo"}	PCS	55.000	71500.000	69.000	90000.000	t	25.000	100.000	0.162	94 x 71 x 43.3 mm	t	f	f	\N	\N	2025-06-26 21:53:56.789054	2025-06-26 21:53:56.789054	\N
15	TEST001	عنصر تجريبي	Test Item	وصف العنصر التجريبي	Test item description	1	Test Brand	Test Model	\N	PCS	10.500	13650.000	15.750	20475.000	t	5.000	20.000	0.500	10x5x2	t	f	f	\N	\N	2025-06-26 22:00:33.316922	2025-06-26 22:00:33.316926	\N
\.


--
-- Data for Name: migration_records; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.migration_records (id, batch_id, entity_type, source_id, source_data, target_id, status, processed_at, error_message, retry_count, requires_manual_review, manual_review_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migration_stock; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.migration_stock (id, item_id, warehouse_id, quantity_on_hand, quantity_reserved, quantity_available, average_cost, last_cost, reorder_level, reorder_quantity, max_stock_level, last_movement_date, last_movement_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migration_vendors; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.migration_vendors (id, code, name_ar, name_en, email, phone, contact_person, address_ar, address_en, city, country, tax_number, currency, payment_terms, outstanding_payable, is_active, zoho_vendor_id, zoho_last_sync, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pos_discounts; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.pos_discounts (id, code, name_ar, name_en, discount_type, discount_value, min_amount, max_amount, min_quantity, applicable_products, applicable_categories, valid_from, valid_to, usage_limit, usage_count, is_active, created_at, updated_at) FROM stdin;
1	STUDENT10	خصم الطلاب	Student Discount	PERCENTAGE	10.00	0.00	\N	\N	\N	\N	2025-06-24 21:13:43.009709	2025-12-31 00:00:00	\N	0	t	2025-06-24 18:13:43.013315	2025-06-24 18:13:43.013315
2	BULK20	خصم الشراء بالجملة	Bulk Purchase Discount	PERCENTAGE	20.00	1000.00	\N	\N	\N	\N	2025-06-24 21:13:43.009712	2025-12-31 00:00:00	\N	0	t	2025-06-24 18:13:43.013316	2025-06-24 18:13:43.013316
\.


--
-- Data for Name: pos_payments; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.pos_payments (id, transaction_id, payment_method, amount, card_type, card_last_four, approval_code, reference_number, mobile_number, mobile_provider, mobile_reference, credit_reference, voucher_code, voucher_type, notes, created_at) FROM stdin;
\.


--
-- Data for Name: pos_promotions; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.pos_promotions (id, code, name_ar, name_en, description_ar, description_en, promotion_type, rules, valid_from, valid_to, usage_limit, usage_count, priority, is_active, created_at, updated_at) FROM stdin;
1	WELCOME2025	عرض أهلاً 2025	Welcome 2025 Promotion	عرض خاص للسنة الجديدة	Special promotion for new year	BUY_X_GET_Y	{"buy": 2, "get": 1, "product_ids": []}	2025-06-24 21:13:43.011585	2025-12-31 00:00:00	\N	0	1	t	2025-06-24 18:13:43.015262	2025-06-24 18:13:43.015262
\.


--
-- Data for Name: pos_sessions; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.pos_sessions (id, session_number, terminal_id, currency_id, user_id, start_time, end_time, status, opening_cash_amount, opening_notes, closing_cash_amount, closing_card_amount, closing_mobile_amount, closing_total_amount, closing_notes, total_sales, total_refunds, total_discounts, total_tax, transaction_count, closed_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pos_terminals; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.pos_terminals (id, terminal_code, name_ar, name_en, branch_id, warehouse_id, receipt_printer, barcode_scanner, cash_drawer, display, default_tax_rate, allow_discount, max_discount_percent, allow_negative_stock, auto_print_receipt, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pos_transaction_items; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.pos_transaction_items (id, transaction_id, product_id, line_number, quantity, unit_price, discount_amount, discount_percent, tax_amount, tax_percent, line_total, notes, created_at) FROM stdin;
\.


--
-- Data for Name: pos_transactions; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.pos_transactions (id, transaction_number, terminal_id, session_id, customer_id, sales_order_id, transaction_type, transaction_date, subtotal, discount_amount, discount_percent, tax_amount, tax_percent, total_amount, amount_paid, change_amount, receipt_number, notes, void_reason, voided_at, voided_by, cashier_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: price_list_items; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.price_list_items (id, price_list_id, item_id, unit_price, discount_percentage, minimum_quantity, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: price_lists; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.price_lists (id, code, name_ar, name_en, description_ar, description_en, currency, is_default, is_active, effective_from, effective_to, zoho_price_list_id, zoho_last_sync, created_at, updated_at, created_by) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.products (id, sku, name, description, category_id, unit_price, cost_price, unit_of_measure, min_stock_level, max_stock_level, reorder_point, barcode, is_active, is_trackable, created_at, updated_at) FROM stdin;
1	TSH-001	جهاز كمبيوتر محمول	جهاز كمبيوتر محمول عالي الأداء	1	2500.00	2000.00	قطعة	5	\N	10	\N	t	t	2025-06-24 20:36:31.732646+03	\N
2	LAP001	لابتوب Dell XPS 15	لابتوب Dell XPS 15 بمعالج Intel i7	2	15000.00	12000.00	قطعة	5	\N	10	\N	t	t	2025-06-24 20:51:17.003861+03	\N
\.


--
-- Data for Name: purchase_invoice_items; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.purchase_invoice_items (id, invoice_id, product_id, purchase_item_id, quantity, unit_cost, discount_percentage, discount_amount, line_total, description, notes) FROM stdin;
\.


--
-- Data for Name: purchase_invoices; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.purchase_invoices (id, invoice_number, supplier_invoice_number, supplier_id, purchase_order_id, branch_id, warehouse_id, invoice_date, due_date, received_date, currency_id, exchange_rate, invoice_type, status, payment_terms, subtotal, discount_percentage, discount_amount, tax_percentage, tax_amount, shipping_amount, total_amount, paid_amount, notes, internal_notes, payment_method, reference_number, created_by, created_at, updated_at, received_at, cancelled_at) FROM stdin;
\.


--
-- Data for Name: purchase_items; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.purchase_items (id, purchase_order_id, product_id, quantity, unit_cost, discount_percentage, discount_amount, line_total, received_quantity, notes) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.purchase_orders (id, order_number, supplier_id, branch_id, warehouse_id, order_date, expected_delivery_date, actual_delivery_date, status, payment_status, payment_method, subtotal, discount_percentage, discount_amount, tax_percentage, tax_amount, total_amount, paid_amount, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.roles (id, name) FROM stdin;
1	Admin
2	Manager
3	Travel Salesperson
4	Warehouse Staff
5	Accountant
6	admin
7	manager
8	sales
9	inventory
10	accounting
11	cashier
12	viewer
\.


--
-- Data for Name: sales_invoice_items; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.sales_invoice_items (id, invoice_id, product_id, sales_item_id, quantity, unit_price, discount_percentage, discount_amount, line_total, description, notes) FROM stdin;
\.


--
-- Data for Name: sales_invoices; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.sales_invoices (id, invoice_number, customer_id, sales_order_id, branch_id, warehouse_id, invoice_date, due_date, currency_id, exchange_rate, invoice_type, status, payment_terms, subtotal, discount_percentage, discount_amount, tax_percentage, tax_amount, shipping_amount, total_amount, paid_amount, notes, internal_notes, payment_method, reference_number, is_recurring, recurring_frequency, parent_invoice_id, created_by, created_at, updated_at, issued_at, cancelled_at) FROM stdin;
\.


--
-- Data for Name: sales_items; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.sales_items (id, sales_order_id, product_id, quantity, unit_price, discount_percentage, discount_amount, line_total, delivered_quantity, notes) FROM stdin;
\.


--
-- Data for Name: sales_orders; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.sales_orders (id, order_number, customer_id, branch_id, warehouse_id, order_date, expected_delivery_date, actual_delivery_date, status, payment_status, payment_method, subtotal, discount_percentage, discount_amount, tax_percentage, tax_amount, total_amount, paid_amount, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: salesperson_regions; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.salesperson_regions (id, user_id, region, is_primary, is_active, assigned_date, created_at, assigned_by) FROM stdin;
1	7	KARBALA	t	t	2025-06-25 20:23:47.780806	2025-06-25 20:23:47.780809	1
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.stock_movements (id, inventory_item_id, movement_type, reference_type, reference_id, quantity, unit_cost, notes, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.suppliers (id, supplier_code, name, company_name, phone, email, address, city, country, tax_number, payment_terms, is_active, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.users (id, name, email, password, role_id, branch_id, employee_code, phone, is_salesperson, is_active, created_at, updated_at, last_login) FROM stdin;
1	Ahmed Kareem	ahmed.kareem@tsh.com	$2b$12$AWqAerPGjikNcomryXAc2O8WT6dnnw6ZkJGVlFLUbz0hxtsyUGkgi	3	2	\N	\N	f	t	2025-06-25 23:15:54.750205	\N	\N
2	Ayad Fadel	ayad.fadel@tsh.com	$2b$12$y1UWaUdCjDobt5hDO.u6POui/2fvGrqy1A3RMpSUz6PdJgnli4TEi	3	2	\N	\N	f	t	2025-06-25 23:15:54.750205	\N	\N
3	Haider Adnan	haider.adnan@tsh.com	$2b$12$5aJRHu04eEboJh7mXiqQ4uGP7aLVTcbCsD1BS2AY.5pjoQuwvXeGm	3	3	\N	\N	f	t	2025-06-25 23:15:54.750205	\N	\N
4	Ayoob Myser	ayoob.myser@tsh.com	$2b$12$RIwknZiuDrn1U78N3qtYT.giTpTpgTYG2ihfCbx5uvEzwbf0pihwG	3	3	\N	\N	f	t	2025-06-25 23:15:54.750205	\N	\N
5	Hussien Hgran	hussien.hgran@tsh.com	$2b$12$QoHcb6G1Opc2r.Gyp4Ss/.wW9DbG0GrgmAY3q3jV.e1JebVpUwPu.	3	2	\N	\N	f	t	2025-06-25 23:15:54.750205	\N	\N
6	TSH Admin	admin@tsh.com	$2b$12$9gK6jnV0c5EMvBtwBSz/1.rYHEGmI0MdqsUzwrvRo3SWBgTWGfU3a	1	2	\N	\N	f	t	2025-06-25 23:15:54.750205	\N	\N
7	أياد البغدادي	ayad.baghdadi@tsh-erp.com	hashed_password_demo	1	1	SP001	+964770123456	t	t	2025-06-25 20:23:28.360473	2025-06-25 20:23:28.36111	\N
8	System Administrator	admin@tsh-erp.com	$2b$12$.W8GD07Fq0AeO9WeH/ui2.P33bdzItvSxF9p5XbxfcEzek41vzTXm	6	4	ADM001	+964-xxx-0001	f	t	2025-06-26 18:04:35.963471	2025-06-26 18:04:35.963473	\N
9	Ahmed Manager	manager@tsh-erp.com	$2b$12$DIyAJUcBhb31qtGEVHqr3.E0EXpkSssT1cgj6sGACOnn8MhKBKMdW	7	4	MGR001	+964-xxx-0002	f	t	2025-06-26 18:04:36.308922	2025-06-26 18:04:36.308927	\N
10	Sara Sales	sales@tsh-erp.com	$2b$12$pP1Zd3VH0CZm47i40W6Ax.uWowcjNOy2Bg9OEmL3bMvYZ8qheuqKW	8	5	SAL001	+964-xxx-0003	t	t	2025-06-26 18:04:36.308928	2025-06-26 18:04:36.308928	\N
11	Test User	test@tsh-erp.com	$2b$12$P/4mXBrxZEXv7ndLnY8UeeTCzXiN02vm8vKkgtKHkRZWNmK7C6X0S	1	1	TEST001	+964-xxx-test	f	t	2025-06-26 18:06:01.097768	2025-06-26 18:06:01.09777	\N
12	Ahmed Al-Salimi	ahmed.salimi@tsh-erp.com	$2b$12$g0crXo/5F4phmlRxlsTIp.npGHcJLD.4BEnxFG0liHB.PnfuU6XW6	8	4	SP002	+964-770-123456	t	t	2025-06-26 19:46:37.201486	2025-06-26 19:46:37.201489	\N
13	Fatima Al-Zahra	fatima.zahra@tsh-erp.com	$2b$12$ULLzCxZpfBX06OO4Ols2fuaLdOYPprgxK2Hxy8aV4SlcIoVzwVCXG	8	5	SP003	+964-771-789012	t	t	2025-06-26 19:46:37.381615	2025-06-26 19:46:37.381616	\N
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: khaleelal-mulla
--

COPY public.warehouses (id, name, branch_id) FROM stdin;
1	المستودع الرئيسي	1
2	Main Wholesale Warehouse	2
3	TSH Dora Storage	3
\.


--
-- Name: accounting_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.accounting_periods_id_seq', 1, false);


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.accounts_id_seq', 4, true);


--
-- Name: branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.branches_id_seq', 5, true);


--
-- Name: cash_boxes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.cash_boxes_id_seq', 3, true);


--
-- Name: cash_flow_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.cash_flow_summaries_id_seq', 1, false);


--
-- Name: cash_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.cash_transactions_id_seq', 2, true);


--
-- Name: cash_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.cash_transfers_id_seq', 1, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.categories_id_seq', 2, true);


--
-- Name: chart_of_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.chart_of_accounts_id_seq', 24, true);


--
-- Name: currencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.currencies_id_seq', 3, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.customers_id_seq', 11, true);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.exchange_rates_id_seq', 1, false);


--
-- Name: fiscal_years_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.fiscal_years_id_seq', 1, true);


--
-- Name: inventory_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.inventory_items_id_seq', 1, false);


--
-- Name: invoice_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.invoice_payments_id_seq', 1, false);


--
-- Name: item_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.item_categories_id_seq', 5, true);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.journal_entries_id_seq', 1, false);


--
-- Name: journal_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.journal_lines_id_seq', 1, false);


--
-- Name: journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.journals_id_seq', 4, true);


--
-- Name: migration_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.migration_batches_id_seq', 1, false);


--
-- Name: migration_customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.migration_customers_id_seq', 12, true);


--
-- Name: migration_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.migration_items_id_seq', 15, true);


--
-- Name: migration_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.migration_records_id_seq', 1, false);


--
-- Name: migration_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.migration_stock_id_seq', 1, false);


--
-- Name: migration_vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.migration_vendors_id_seq', 1, false);


--
-- Name: pos_discounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.pos_discounts_id_seq', 2, true);


--
-- Name: pos_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.pos_payments_id_seq', 1, false);


--
-- Name: pos_promotions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.pos_promotions_id_seq', 1, true);


--
-- Name: pos_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.pos_sessions_id_seq', 1, false);


--
-- Name: pos_terminals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.pos_terminals_id_seq', 1, false);


--
-- Name: pos_transaction_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.pos_transaction_items_id_seq', 1, false);


--
-- Name: pos_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.pos_transactions_id_seq', 1, false);


--
-- Name: price_list_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.price_list_items_id_seq', 1, false);


--
-- Name: price_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.price_lists_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.products_id_seq', 2, true);


--
-- Name: purchase_invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.purchase_invoice_items_id_seq', 1, false);


--
-- Name: purchase_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.purchase_invoices_id_seq', 1, false);


--
-- Name: purchase_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.purchase_items_id_seq', 1, false);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.purchase_orders_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.roles_id_seq', 12, true);


--
-- Name: sales_invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.sales_invoice_items_id_seq', 1, false);


--
-- Name: sales_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.sales_invoices_id_seq', 1, false);


--
-- Name: sales_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.sales_items_id_seq', 1, false);


--
-- Name: sales_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.sales_orders_id_seq', 1, false);


--
-- Name: salesperson_regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.salesperson_regions_id_seq', 1, true);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 1, false);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.users_id_seq', 13, true);


--
-- Name: warehouses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: khaleelal-mulla
--

SELECT pg_catalog.setval('public.warehouses_id_seq', 3, true);


--
-- Name: accounting_periods accounting_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.accounting_periods
    ADD CONSTRAINT accounting_periods_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: cash_boxes cash_boxes_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_boxes
    ADD CONSTRAINT cash_boxes_pkey PRIMARY KEY (id);


--
-- Name: cash_flow_summaries cash_flow_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_flow_summaries
    ADD CONSTRAINT cash_flow_summaries_pkey PRIMARY KEY (id);


--
-- Name: cash_transactions cash_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transactions
    ADD CONSTRAINT cash_transactions_pkey PRIMARY KEY (id);


--
-- Name: cash_transfers cash_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transfers
    ADD CONSTRAINT cash_transfers_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: chart_of_accounts chart_of_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_pkey PRIMARY KEY (id);


--
-- Name: currencies currencies_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.currencies
    ADD CONSTRAINT currencies_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: fiscal_years fiscal_years_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.fiscal_years
    ADD CONSTRAINT fiscal_years_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_payments invoice_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_pkey PRIMARY KEY (id);


--
-- Name: item_categories item_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.item_categories
    ADD CONSTRAINT item_categories_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_lines journal_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_pkey PRIMARY KEY (id);


--
-- Name: journals journals_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journals
    ADD CONSTRAINT journals_pkey PRIMARY KEY (id);


--
-- Name: migration_batches migration_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_batches
    ADD CONSTRAINT migration_batches_pkey PRIMARY KEY (id);


--
-- Name: migration_customers migration_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_customers
    ADD CONSTRAINT migration_customers_pkey PRIMARY KEY (id);


--
-- Name: migration_items migration_items_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_items
    ADD CONSTRAINT migration_items_pkey PRIMARY KEY (id);


--
-- Name: migration_records migration_records_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_records
    ADD CONSTRAINT migration_records_pkey PRIMARY KEY (id);


--
-- Name: migration_stock migration_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_stock
    ADD CONSTRAINT migration_stock_pkey PRIMARY KEY (id);


--
-- Name: migration_vendors migration_vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_vendors
    ADD CONSTRAINT migration_vendors_pkey PRIMARY KEY (id);


--
-- Name: pos_discounts pos_discounts_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_discounts
    ADD CONSTRAINT pos_discounts_pkey PRIMARY KEY (id);


--
-- Name: pos_payments pos_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_payments
    ADD CONSTRAINT pos_payments_pkey PRIMARY KEY (id);


--
-- Name: pos_promotions pos_promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_promotions
    ADD CONSTRAINT pos_promotions_pkey PRIMARY KEY (id);


--
-- Name: pos_sessions pos_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_sessions
    ADD CONSTRAINT pos_sessions_pkey PRIMARY KEY (id);


--
-- Name: pos_terminals pos_terminals_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_terminals
    ADD CONSTRAINT pos_terminals_pkey PRIMARY KEY (id);


--
-- Name: pos_transaction_items pos_transaction_items_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transaction_items
    ADD CONSTRAINT pos_transaction_items_pkey PRIMARY KEY (id);


--
-- Name: pos_transactions pos_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_pkey PRIMARY KEY (id);


--
-- Name: price_list_items price_list_items_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.price_list_items
    ADD CONSTRAINT price_list_items_pkey PRIMARY KEY (id);


--
-- Name: price_lists price_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.price_lists
    ADD CONSTRAINT price_lists_pkey PRIMARY KEY (id);


--
-- Name: products products_barcode_key; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_barcode_key UNIQUE (barcode);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_invoice_items purchase_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoice_items
    ADD CONSTRAINT purchase_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_invoices purchase_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_pkey PRIMARY KEY (id);


--
-- Name: purchase_items purchase_items_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sales_invoice_items sales_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoice_items
    ADD CONSTRAINT sales_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: sales_invoices sales_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_pkey PRIMARY KEY (id);


--
-- Name: sales_items sales_items_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT sales_items_pkey PRIMARY KEY (id);


--
-- Name: sales_orders sales_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_pkey PRIMARY KEY (id);


--
-- Name: salesperson_regions salesperson_regions_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.salesperson_regions
    ADD CONSTRAINT salesperson_regions_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: idx_customer_region; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_customer_region ON public.migration_customers USING btree (region);


--
-- Name: idx_customer_salesperson; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_customer_salesperson ON public.migration_customers USING btree (salesperson_id);


--
-- Name: idx_customer_zoho; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_customer_zoho ON public.migration_customers USING btree (zoho_customer_id);


--
-- Name: idx_item_brand_model; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_item_brand_model ON public.migration_items USING btree (brand, model);


--
-- Name: idx_item_category; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_item_category ON public.migration_items USING btree (category_id);


--
-- Name: idx_item_zoho; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_item_zoho ON public.migration_items USING btree (zoho_item_id);


--
-- Name: idx_migration_record_batch_entity; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_migration_record_batch_entity ON public.migration_records USING btree (batch_id, entity_type);


--
-- Name: idx_migration_record_entity_source; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_migration_record_entity_source ON public.migration_records USING btree (entity_type, source_id);


--
-- Name: idx_migration_record_status; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_migration_record_status ON public.migration_records USING btree (status);


--
-- Name: idx_price_list_item; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_price_list_item ON public.price_list_items USING btree (price_list_id, item_id);


--
-- Name: idx_stock_item; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_stock_item ON public.migration_stock USING btree (item_id);


--
-- Name: idx_stock_item_warehouse; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_stock_item_warehouse ON public.migration_stock USING btree (item_id, warehouse_id);


--
-- Name: idx_stock_warehouse; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_stock_warehouse ON public.migration_stock USING btree (warehouse_id);


--
-- Name: idx_vendor_zoho; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX idx_vendor_zoho ON public.migration_vendors USING btree (zoho_vendor_id);


--
-- Name: ix_accounting_periods_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_accounting_periods_id ON public.accounting_periods USING btree (id);


--
-- Name: ix_accounts_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_accounts_id ON public.accounts USING btree (id);


--
-- Name: ix_branches_branch_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_branches_branch_code ON public.branches USING btree (branch_code);


--
-- Name: ix_branches_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_branches_id ON public.branches USING btree (id);


--
-- Name: ix_branches_name; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_branches_name ON public.branches USING btree (name);


--
-- Name: ix_cash_boxes_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_cash_boxes_code ON public.cash_boxes USING btree (code);


--
-- Name: ix_cash_boxes_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_cash_boxes_id ON public.cash_boxes USING btree (id);


--
-- Name: ix_cash_flow_summaries_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_cash_flow_summaries_id ON public.cash_flow_summaries USING btree (id);


--
-- Name: ix_cash_transactions_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_cash_transactions_id ON public.cash_transactions USING btree (id);


--
-- Name: ix_cash_transactions_transaction_number; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_cash_transactions_transaction_number ON public.cash_transactions USING btree (transaction_number);


--
-- Name: ix_cash_transfers_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_cash_transfers_id ON public.cash_transfers USING btree (id);


--
-- Name: ix_cash_transfers_transfer_number; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_cash_transfers_transfer_number ON public.cash_transfers USING btree (transfer_number);


--
-- Name: ix_categories_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_categories_id ON public.categories USING btree (id);


--
-- Name: ix_categories_name; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_categories_name ON public.categories USING btree (name);


--
-- Name: ix_chart_of_accounts_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_chart_of_accounts_code ON public.chart_of_accounts USING btree (code);


--
-- Name: ix_chart_of_accounts_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_chart_of_accounts_id ON public.chart_of_accounts USING btree (id);


--
-- Name: ix_currencies_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_currencies_code ON public.currencies USING btree (code);


--
-- Name: ix_currencies_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_currencies_id ON public.currencies USING btree (id);


--
-- Name: ix_customers_customer_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_customers_customer_code ON public.customers USING btree (customer_code);


--
-- Name: ix_customers_email; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_customers_email ON public.customers USING btree (email);


--
-- Name: ix_customers_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_customers_id ON public.customers USING btree (id);


--
-- Name: ix_customers_name; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_customers_name ON public.customers USING btree (name);


--
-- Name: ix_customers_phone; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_customers_phone ON public.customers USING btree (phone);


--
-- Name: ix_exchange_rates_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_exchange_rates_id ON public.exchange_rates USING btree (id);


--
-- Name: ix_fiscal_years_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_fiscal_years_id ON public.fiscal_years USING btree (id);


--
-- Name: ix_inventory_items_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_inventory_items_id ON public.inventory_items USING btree (id);


--
-- Name: ix_invoice_payments_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_invoice_payments_id ON public.invoice_payments USING btree (id);


--
-- Name: ix_invoice_payments_payment_number; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_invoice_payments_payment_number ON public.invoice_payments USING btree (payment_number);


--
-- Name: ix_item_categories_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_item_categories_code ON public.item_categories USING btree (code);


--
-- Name: ix_item_categories_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_item_categories_id ON public.item_categories USING btree (id);


--
-- Name: ix_journal_entries_entry_number; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_journal_entries_entry_number ON public.journal_entries USING btree (entry_number);


--
-- Name: ix_journal_entries_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_journal_entries_id ON public.journal_entries USING btree (id);


--
-- Name: ix_journal_lines_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_journal_lines_id ON public.journal_lines USING btree (id);


--
-- Name: ix_journals_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_journals_code ON public.journals USING btree (code);


--
-- Name: ix_journals_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_journals_id ON public.journals USING btree (id);


--
-- Name: ix_migration_batches_batch_number; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_migration_batches_batch_number ON public.migration_batches USING btree (batch_number);


--
-- Name: ix_migration_batches_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_migration_batches_id ON public.migration_batches USING btree (id);


--
-- Name: ix_migration_customers_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_migration_customers_code ON public.migration_customers USING btree (code);


--
-- Name: ix_migration_customers_email; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_migration_customers_email ON public.migration_customers USING btree (email);


--
-- Name: ix_migration_customers_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_migration_customers_id ON public.migration_customers USING btree (id);


--
-- Name: ix_migration_customers_zoho_customer_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_migration_customers_zoho_customer_id ON public.migration_customers USING btree (zoho_customer_id);


--
-- Name: ix_migration_items_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_migration_items_code ON public.migration_items USING btree (code);


--
-- Name: ix_migration_items_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_migration_items_id ON public.migration_items USING btree (id);


--
-- Name: ix_migration_items_zoho_item_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_migration_items_zoho_item_id ON public.migration_items USING btree (zoho_item_id);


--
-- Name: ix_migration_records_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_migration_records_id ON public.migration_records USING btree (id);


--
-- Name: ix_migration_stock_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_migration_stock_id ON public.migration_stock USING btree (id);


--
-- Name: ix_migration_vendors_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_migration_vendors_code ON public.migration_vendors USING btree (code);


--
-- Name: ix_migration_vendors_email; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_migration_vendors_email ON public.migration_vendors USING btree (email);


--
-- Name: ix_migration_vendors_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_migration_vendors_id ON public.migration_vendors USING btree (id);


--
-- Name: ix_migration_vendors_zoho_vendor_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_migration_vendors_zoho_vendor_id ON public.migration_vendors USING btree (zoho_vendor_id);


--
-- Name: ix_pos_discounts_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_pos_discounts_code ON public.pos_discounts USING btree (code);


--
-- Name: ix_pos_discounts_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_pos_discounts_id ON public.pos_discounts USING btree (id);


--
-- Name: ix_pos_payments_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_pos_payments_id ON public.pos_payments USING btree (id);


--
-- Name: ix_pos_promotions_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_pos_promotions_code ON public.pos_promotions USING btree (code);


--
-- Name: ix_pos_promotions_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_pos_promotions_id ON public.pos_promotions USING btree (id);


--
-- Name: ix_pos_sessions_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_pos_sessions_id ON public.pos_sessions USING btree (id);


--
-- Name: ix_pos_sessions_session_number; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_pos_sessions_session_number ON public.pos_sessions USING btree (session_number);


--
-- Name: ix_pos_terminals_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_pos_terminals_id ON public.pos_terminals USING btree (id);


--
-- Name: ix_pos_terminals_terminal_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_pos_terminals_terminal_code ON public.pos_terminals USING btree (terminal_code);


--
-- Name: ix_pos_transaction_items_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_pos_transaction_items_id ON public.pos_transaction_items USING btree (id);


--
-- Name: ix_pos_transactions_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_pos_transactions_id ON public.pos_transactions USING btree (id);


--
-- Name: ix_pos_transactions_transaction_number; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_pos_transactions_transaction_number ON public.pos_transactions USING btree (transaction_number);


--
-- Name: ix_price_list_items_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_price_list_items_id ON public.price_list_items USING btree (id);


--
-- Name: ix_price_lists_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_price_lists_code ON public.price_lists USING btree (code);


--
-- Name: ix_price_lists_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_price_lists_id ON public.price_lists USING btree (id);


--
-- Name: ix_price_lists_zoho_price_list_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_price_lists_zoho_price_list_id ON public.price_lists USING btree (zoho_price_list_id);


--
-- Name: ix_products_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_products_id ON public.products USING btree (id);


--
-- Name: ix_products_name; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_products_name ON public.products USING btree (name);


--
-- Name: ix_products_sku; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_products_sku ON public.products USING btree (sku);


--
-- Name: ix_purchase_invoice_items_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_purchase_invoice_items_id ON public.purchase_invoice_items USING btree (id);


--
-- Name: ix_purchase_invoices_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_purchase_invoices_id ON public.purchase_invoices USING btree (id);


--
-- Name: ix_purchase_invoices_invoice_number; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_purchase_invoices_invoice_number ON public.purchase_invoices USING btree (invoice_number);


--
-- Name: ix_purchase_items_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_purchase_items_id ON public.purchase_items USING btree (id);


--
-- Name: ix_purchase_orders_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_purchase_orders_id ON public.purchase_orders USING btree (id);


--
-- Name: ix_purchase_orders_order_date; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_purchase_orders_order_date ON public.purchase_orders USING btree (order_date);


--
-- Name: ix_purchase_orders_order_number; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_purchase_orders_order_number ON public.purchase_orders USING btree (order_number);


--
-- Name: ix_purchase_orders_payment_status; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_purchase_orders_payment_status ON public.purchase_orders USING btree (payment_status);


--
-- Name: ix_purchase_orders_status; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_purchase_orders_status ON public.purchase_orders USING btree (status);


--
-- Name: ix_roles_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_roles_id ON public.roles USING btree (id);


--
-- Name: ix_roles_name; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_roles_name ON public.roles USING btree (name);


--
-- Name: ix_sales_invoice_items_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_sales_invoice_items_id ON public.sales_invoice_items USING btree (id);


--
-- Name: ix_sales_invoices_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_sales_invoices_id ON public.sales_invoices USING btree (id);


--
-- Name: ix_sales_invoices_invoice_number; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_sales_invoices_invoice_number ON public.sales_invoices USING btree (invoice_number);


--
-- Name: ix_sales_items_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_sales_items_id ON public.sales_items USING btree (id);


--
-- Name: ix_sales_orders_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_sales_orders_id ON public.sales_orders USING btree (id);


--
-- Name: ix_sales_orders_order_date; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_sales_orders_order_date ON public.sales_orders USING btree (order_date);


--
-- Name: ix_sales_orders_order_number; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_sales_orders_order_number ON public.sales_orders USING btree (order_number);


--
-- Name: ix_sales_orders_payment_status; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_sales_orders_payment_status ON public.sales_orders USING btree (payment_status);


--
-- Name: ix_sales_orders_status; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_sales_orders_status ON public.sales_orders USING btree (status);


--
-- Name: ix_salesperson_regions_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_salesperson_regions_id ON public.salesperson_regions USING btree (id);


--
-- Name: ix_stock_movements_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_stock_movements_id ON public.stock_movements USING btree (id);


--
-- Name: ix_suppliers_email; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_suppliers_email ON public.suppliers USING btree (email);


--
-- Name: ix_suppliers_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_suppliers_id ON public.suppliers USING btree (id);


--
-- Name: ix_suppliers_name; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_suppliers_name ON public.suppliers USING btree (name);


--
-- Name: ix_suppliers_phone; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_suppliers_phone ON public.suppliers USING btree (phone);


--
-- Name: ix_suppliers_supplier_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_suppliers_supplier_code ON public.suppliers USING btree (supplier_code);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_employee_code; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE UNIQUE INDEX ix_users_employee_code ON public.users USING btree (employee_code);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_name; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_users_name ON public.users USING btree (name);


--
-- Name: ix_warehouses_id; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_warehouses_id ON public.warehouses USING btree (id);


--
-- Name: ix_warehouses_name; Type: INDEX; Schema: public; Owner: khaleelal-mulla
--

CREATE INDEX ix_warehouses_name ON public.warehouses USING btree (name);


--
-- Name: accounting_periods accounting_periods_fiscal_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.accounting_periods
    ADD CONSTRAINT accounting_periods_fiscal_year_id_fkey FOREIGN KEY (fiscal_year_id) REFERENCES public.fiscal_years(id);


--
-- Name: accounts accounts_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: accounts accounts_chart_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_chart_account_id_fkey FOREIGN KEY (chart_account_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: accounts accounts_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: cash_boxes cash_boxes_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_boxes
    ADD CONSTRAINT cash_boxes_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: cash_boxes cash_boxes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_boxes
    ADD CONSTRAINT cash_boxes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: cash_boxes cash_boxes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_boxes
    ADD CONSTRAINT cash_boxes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cash_flow_summaries cash_flow_summaries_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_flow_summaries
    ADD CONSTRAINT cash_flow_summaries_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: cash_flow_summaries cash_flow_summaries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_flow_summaries
    ADD CONSTRAINT cash_flow_summaries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cash_transactions cash_transactions_cash_box_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transactions
    ADD CONSTRAINT cash_transactions_cash_box_id_fkey FOREIGN KEY (cash_box_id) REFERENCES public.cash_boxes(id);


--
-- Name: cash_transactions cash_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transactions
    ADD CONSTRAINT cash_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: cash_transactions cash_transactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transactions
    ADD CONSTRAINT cash_transactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: cash_transfers cash_transfers_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transfers
    ADD CONSTRAINT cash_transfers_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: cash_transfers cash_transfers_from_cash_box_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transfers
    ADD CONSTRAINT cash_transfers_from_cash_box_id_fkey FOREIGN KEY (from_cash_box_id) REFERENCES public.cash_boxes(id);


--
-- Name: cash_transfers cash_transfers_received_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transfers
    ADD CONSTRAINT cash_transfers_received_by_fkey FOREIGN KEY (received_by) REFERENCES public.users(id);


--
-- Name: cash_transfers cash_transfers_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transfers
    ADD CONSTRAINT cash_transfers_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: cash_transfers cash_transfers_to_cash_box_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.cash_transfers
    ADD CONSTRAINT cash_transfers_to_cash_box_id_fkey FOREIGN KEY (to_cash_box_id) REFERENCES public.cash_boxes(id);


--
-- Name: categories categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.categories(id);


--
-- Name: chart_of_accounts chart_of_accounts_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.chart_of_accounts
    ADD CONSTRAINT chart_of_accounts_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.chart_of_accounts(id);


--
-- Name: customers customers_salesperson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_salesperson_id_fkey FOREIGN KEY (salesperson_id) REFERENCES public.users(id);


--
-- Name: exchange_rates exchange_rates_from_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_from_currency_id_fkey FOREIGN KEY (from_currency_id) REFERENCES public.currencies(id);


--
-- Name: exchange_rates exchange_rates_to_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_to_currency_id_fkey FOREIGN KEY (to_currency_id) REFERENCES public.currencies(id);


--
-- Name: inventory_items inventory_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: inventory_items inventory_items_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: invoice_payments invoice_payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: invoice_payments invoice_payments_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: invoice_payments invoice_payments_purchase_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_purchase_invoice_id_fkey FOREIGN KEY (purchase_invoice_id) REFERENCES public.purchase_invoices(id);


--
-- Name: invoice_payments invoice_payments_sales_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_sales_invoice_id_fkey FOREIGN KEY (sales_invoice_id) REFERENCES public.sales_invoices(id);


--
-- Name: item_categories item_categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.item_categories
    ADD CONSTRAINT item_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.item_categories(id);


--
-- Name: journal_entries journal_entries_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: journal_entries journal_entries_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: journal_entries journal_entries_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: journal_entries journal_entries_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_journal_id_fkey FOREIGN KEY (journal_id) REFERENCES public.journals(id);


--
-- Name: journal_entries journal_entries_posted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_posted_by_fkey FOREIGN KEY (posted_by) REFERENCES public.users(id);


--
-- Name: journal_lines journal_lines_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: journal_lines journal_lines_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id);


--
-- Name: migration_batches migration_batches_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_batches
    ADD CONSTRAINT migration_batches_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: migration_customers migration_customers_price_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_customers
    ADD CONSTRAINT migration_customers_price_list_id_fkey FOREIGN KEY (price_list_id) REFERENCES public.price_lists(id);


--
-- Name: migration_customers migration_customers_salesperson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_customers
    ADD CONSTRAINT migration_customers_salesperson_id_fkey FOREIGN KEY (salesperson_id) REFERENCES public.users(id);


--
-- Name: migration_items migration_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_items
    ADD CONSTRAINT migration_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.item_categories(id);


--
-- Name: migration_items migration_items_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_items
    ADD CONSTRAINT migration_items_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: migration_records migration_records_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_records
    ADD CONSTRAINT migration_records_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.migration_batches(id);


--
-- Name: migration_stock migration_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_stock
    ADD CONSTRAINT migration_stock_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.migration_items(id);


--
-- Name: migration_stock migration_stock_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.migration_stock
    ADD CONSTRAINT migration_stock_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: pos_payments pos_payments_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_payments
    ADD CONSTRAINT pos_payments_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.pos_transactions(id);


--
-- Name: pos_sessions pos_sessions_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_sessions
    ADD CONSTRAINT pos_sessions_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id);


--
-- Name: pos_sessions pos_sessions_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_sessions
    ADD CONSTRAINT pos_sessions_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: pos_sessions pos_sessions_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_sessions
    ADD CONSTRAINT pos_sessions_terminal_id_fkey FOREIGN KEY (terminal_id) REFERENCES public.pos_terminals(id);


--
-- Name: pos_sessions pos_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_sessions
    ADD CONSTRAINT pos_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: pos_terminals pos_terminals_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_terminals
    ADD CONSTRAINT pos_terminals_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: pos_terminals pos_terminals_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_terminals
    ADD CONSTRAINT pos_terminals_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: pos_transaction_items pos_transaction_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transaction_items
    ADD CONSTRAINT pos_transaction_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: pos_transaction_items pos_transaction_items_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transaction_items
    ADD CONSTRAINT pos_transaction_items_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.pos_transactions(id);


--
-- Name: pos_transactions pos_transactions_cashier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_cashier_id_fkey FOREIGN KEY (cashier_id) REFERENCES public.users(id);


--
-- Name: pos_transactions pos_transactions_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: pos_transactions pos_transactions_sales_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.sales_orders(id);


--
-- Name: pos_transactions pos_transactions_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.pos_sessions(id);


--
-- Name: pos_transactions pos_transactions_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_terminal_id_fkey FOREIGN KEY (terminal_id) REFERENCES public.pos_terminals(id);


--
-- Name: pos_transactions pos_transactions_voided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_voided_by_fkey FOREIGN KEY (voided_by) REFERENCES public.users(id);


--
-- Name: price_list_items price_list_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.price_list_items
    ADD CONSTRAINT price_list_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.migration_items(id);


--
-- Name: price_list_items price_list_items_price_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.price_list_items
    ADD CONSTRAINT price_list_items_price_list_id_fkey FOREIGN KEY (price_list_id) REFERENCES public.price_lists(id);


--
-- Name: price_lists price_lists_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.price_lists
    ADD CONSTRAINT price_lists_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: purchase_invoice_items purchase_invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoice_items
    ADD CONSTRAINT purchase_invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.purchase_invoices(id);


--
-- Name: purchase_invoice_items purchase_invoice_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoice_items
    ADD CONSTRAINT purchase_invoice_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: purchase_invoice_items purchase_invoice_items_purchase_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoice_items
    ADD CONSTRAINT purchase_invoice_items_purchase_item_id_fkey FOREIGN KEY (purchase_item_id) REFERENCES public.purchase_items(id);


--
-- Name: purchase_invoices purchase_invoices_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: purchase_invoices purchase_invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: purchase_invoices purchase_invoices_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: purchase_invoices purchase_invoices_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id);


--
-- Name: purchase_invoices purchase_invoices_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: purchase_invoices purchase_invoices_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: purchase_items purchase_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: purchase_items purchase_items_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id);


--
-- Name: purchase_orders purchase_orders_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: purchase_orders purchase_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: purchase_orders purchase_orders_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: sales_invoice_items sales_invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoice_items
    ADD CONSTRAINT sales_invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.sales_invoices(id);


--
-- Name: sales_invoice_items sales_invoice_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoice_items
    ADD CONSTRAINT sales_invoice_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: sales_invoice_items sales_invoice_items_sales_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoice_items
    ADD CONSTRAINT sales_invoice_items_sales_item_id_fkey FOREIGN KEY (sales_item_id) REFERENCES public.sales_items(id);


--
-- Name: sales_invoices sales_invoices_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: sales_invoices sales_invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: sales_invoices sales_invoices_currency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_currency_id_fkey FOREIGN KEY (currency_id) REFERENCES public.currencies(id);


--
-- Name: sales_invoices sales_invoices_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: sales_invoices sales_invoices_parent_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_parent_invoice_id_fkey FOREIGN KEY (parent_invoice_id) REFERENCES public.sales_invoices(id);


--
-- Name: sales_invoices sales_invoices_sales_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.sales_orders(id);


--
-- Name: sales_invoices sales_invoices_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: sales_items sales_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT sales_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: sales_items sales_items_sales_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT sales_items_sales_order_id_fkey FOREIGN KEY (sales_order_id) REFERENCES public.sales_orders(id);


--
-- Name: sales_orders sales_orders_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: sales_orders sales_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: sales_orders sales_orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: sales_orders sales_orders_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id);


--
-- Name: salesperson_regions salesperson_regions_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.salesperson_regions
    ADD CONSTRAINT salesperson_regions_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: salesperson_regions salesperson_regions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.salesperson_regions
    ADD CONSTRAINT salesperson_regions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: stock_movements stock_movements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stock_movements stock_movements_inventory_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_inventory_item_id_fkey FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_items(id);


--
-- Name: users users_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: warehouses warehouses_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: khaleelal-mulla
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- PostgreSQL database dump complete
--

